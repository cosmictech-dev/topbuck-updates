document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart;
  function card(n) { return '<article class="card hover news-card"><a class="news-thumb" href="article.html?id=' + n.id + '" aria-label="' + C.esc(n.title) + '">' + C.thumb(n.id.length * 7 + parseInt(n.id.slice(1)) * 13, n.cat) + '</a><div class="meta"><span class="tag">' + n.cat + '</span><span class="tag ex">Example</span><span>' + n.mins + ' min</span></div><h3><a href="article.html?id=' + n.id + '">' + C.esc(n.title) + '</a></h3><p class="small muted" style="margin:0">' + C.esc(n.dek) + '</p></article>'; }
  var ins = D.news.filter(function (n) { return n.type === 'insight'; });
  document.getElementById('home-insights').innerHTML = card(ins[0]) + '<div class="stack">' + ins.slice(1, 3).map(card).join('') + '</div>';
  var ix = D.indices.slice(0, 5);
  document.getElementById('home-mkts').innerHTML = ix.map(function (i) { var vals = D.series(i.seed, 30, 100, 0.012, i.chg >= 0 ? 0.002 : -0.001); return '<div class="mkt-row"><div><div class="nm">' + i.name + '</div><div class="sub">' + i.mkt + ' · example</div></div>' + C.spark(vals, i.chg >= 0 ? '#58C28A' : '#E4796B') + '<div style="text-align:right"><div class="num" style="font-weight:700">' + TB.group(i.last, 1) + '</div><div class="small">' + TB.chg(i.chg) + '</div></div></div>'; }).join('');
  document.getElementById('home-news').innerHTML = D.news.filter(function (n) { return n.type === 'news'; }).slice(0, 5).map(function (n) { return '<div class="mkt-row" style="grid-template-columns:1fr"><div><div class="meta" style="margin-bottom:4px"><span class="tag">' + n.cat + '</span><span>' + n.date + '</span></div><a href="article.html?id=' + n.id + '" style="color:var(--ivory-50);font-weight:700">' + C.esc(n.title) + '</a></div></div>'; }).join('');
  var tools = [
    ['retirement.html', 'Retirement calculator', 'Will your savings last?', '<path d="M12 3v18M5 9l7-6 7 6M4 21h16M7 21v-6h10v6"/>'],
    ['mortgage.html', 'Home loan calculator', 'What will the bond really cost?', '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'],
    ['education.html', 'Education fees calculator', 'Plan school and university with clear inflation paths.', '<path d="M2 9l10-5 10 5-10 5zM6 11.5V16c0 1.5 3 3 6 3s6-1.500 6-3v-4.500"/>'],
    ['car-valuator.html', 'Used car valuator', 'A transparent ballpark from age, mileage and condition.', '<path d="M3 15l2-6a2 2 0 0 1 2-1.500h10a2 2 0 0 1 2 1.500l2 6v4h-3v-2H6v2H3zM7 15h.01M17 15h.01"/>']];
  document.getElementById('home-tools').innerHTML = tools.map(function (t) { return '<a class="card hover tool-card" href="' + t[0] + '" style="color:inherit"><div class="tool-ico"><svg viewBox="0 0 24 24">' + t[3] + '</svg></div><h3 style="margin:0">' + t[1] + '</h3><p class="small muted" style="margin:0">' + t[2] + '</p><span class="go">Open →</span></a>'; }).join('');
});
