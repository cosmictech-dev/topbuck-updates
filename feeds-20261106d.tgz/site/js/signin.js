document.addEventListener('tb:ready', function () {
  document.getElementById('go').addEventListener('click', function () { location.href = 'client.html'; });
});
