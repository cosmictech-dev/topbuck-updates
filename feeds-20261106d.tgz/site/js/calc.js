/* TopBuck calculators — pure functions (no DOM). Works in browser (window.TBCalc) and Node (module.exports) for tests.
   All outputs are ESTIMATES for illustration. Rates are annual effective unless stated. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TBCalc = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var pct = function (x) { return x / 100; };
  // annual effective -> monthly effective
  var mEff = function (a) { return Math.pow(1 + a, 1 / 12) - 1; };

  /* ---------------- Retirement ---------------- */
  function retirement(o) {
    var n = o.retAge - o.age, N = Math.round(n * 12);
    var i = mEff(pct(o.preRet)), g = pct(o.escal || 0), infl = pct(o.infl);
    var bal = o.savings, contribFV = 0, rows = [];
    var years = [{ age: o.age, nominal: o.savings, real: o.savings }];
    for (var m = 1; m <= N; m++) {
      var c = o.monthly * Math.pow(1 + g, Math.floor((m - 1) / 12));
      bal = bal * (1 + i) + c;
      contribFV = contribFV * (1 + i) + c;
      if (m % 12 === 0 || m === N) {
        var age = o.age + m / 12;
        years.push({ age: age, nominal: bal, real: bal / Math.pow(1 + infl, m / 12) });
      }
    }
    var nominalAtRet = bal, realAtRet = bal / Math.pow(1 + infl, N / 12);
    var ir = Math.pow((1 + pct(o.postRet)) / (1 + infl), 1 / 12) - 1;
    var R = Math.round((o.planAge - o.retAge) * 12);
    var annuityFactor = Math.abs(ir) < 1e-12 ? R : (1 - Math.pow(1 + ir, -R)) / ir; // PV of R1/month (real), end-of-month
    var sustainableReal = realAtRet / annuityFactor;                              // today's money, monthly
    var requiredReal = o.targetIncome * annuityFactor;
    var shortfallReal = Math.max(0, requiredReal - realAtRet);
    var shortfallNominal = shortfallReal * Math.pow(1 + infl, N / 12);
    // FV factor of R1/month contribution (with escalation) at retirement
    var f = 0; for (var k = 1; k <= N; k++) f = f * (1 + i) + Math.pow(1 + g, Math.floor((k - 1) / 12));
    var extraMonthly = f > 0 ? shortfallNominal / f : 0;
    // drawdown path (today's money) at sustainable income
    var draw = [], rb = realAtRet;
    draw.push({ age: o.retAge, real: rb });
    for (var d = 1; d <= R; d++) {
      rb = rb * (1 + ir) - sustainableReal;
      if (d % 12 === 0 || d === R) draw.push({ age: o.retAge + d / 12, real: Math.max(rb, 0) });
    }
    var out = {
      months: N, nominalAtRet: nominalAtRet, realAtRet: realAtRet, contribFV: contribFV,
      sustainableReal: sustainableReal, sustainableNominalAtRet: sustainableReal * Math.pow(1 + infl, N / 12),
      requiredReal: requiredReal, shortfallReal: shortfallReal, extraMonthly: extraMonthly,
      replacement: o.salary ? sustainableReal / o.salary : null,
      onTrack: realAtRet >= requiredReal, years: years, draw: draw, annuityFactor: annuityFactor
    };
    if (o.twoPot) { // illustrative SA two-pot split: existing balance = vested, new contributions 1/3 savings : 2/3 retirement
      var existingFV = o.savings * Math.pow(1 + i, N);
      out.pots = { vested: existingFV, savings: contribFV / 3, retirement: contribFV * 2 / 3 };
    }
    return out;
  }

  /* ---------------- Mortgage ---------------- */
  function pmt(P, annualNominalPct, years) {
    var n = Math.round(years * 12), i = annualNominalPct / 100 / 12;
    if (i === 0) return P / n;
    return P * i / (1 - Math.pow(1 + i, -n));
  }
  function mortgage(o) {
    var P = o.price * (1 - o.depositPct / 100);
    var i = o.rate / 100 / 12, n = Math.round(o.years * 12);
    var base = pmt(P, o.rate, o.years), extra = o.extra || 0;
    function run(ex) {
      var bal = P, rows = [], totInt = 0, m = 0;
      while (bal > 0.005 && m < n + 600) {
        m++;
        var int = bal * i, pay = Math.min(base + ex, bal + int), prin = pay - int;
        bal -= prin; totInt += int;
        rows.push({ m: m, payment: pay, interest: int, principal: prin, balance: Math.max(bal, 0) });
      }
      return { rows: rows, totalInterest: totInt, months: m };
    }
    var a = run(extra), b = extra > 0 ? run(0) : a;
    var yearly = [];
    for (var y = 1; y <= Math.ceil(a.months / 12); y++) {
      var slice = a.rows.slice((y - 1) * 12, y * 12);
      yearly.push({ year: y, interest: sum(slice, 'interest'), principal: sum(slice, 'principal'), balance: slice[slice.length - 1].balance });
    }
    return {
      loan: P, deposit: o.price - P, payment: base, totalPaid: a.rows.reduce(function (s, r) { return s + r.payment; }, 0),
      totalInterest: a.totalInterest, months: a.months, interestSaved: b.totalInterest - a.totalInterest,
      monthsSaved: b.months - a.months, rows: a.rows, yearly: yearly,
      requiredIncome: (base + (extra || 0)) / 0.3 // common bank affordability rule of thumb: repayment ≤ 30% of gross income (illustrative)
    };
  }

  /* ---------------- Education ---------------- */
  function education(o) {
    var r = pct(o.ret), im = mEff(r);
    var pays = []; // {t (yrs from now), cost, kind}
    var a, t;
    for (a = Math.max(o.childAge, o.schoolStartAge); a < o.schoolStartAge + o.schoolYears; a++) {
      t = a - o.childAge; pays.push({ t: t, age: a, kind: 'School', cost: o.schoolFee * Math.pow(1 + pct(o.schoolInfl), t) });
    }
    for (a = Math.max(o.childAge, o.uniStartAge); a < o.uniStartAge + o.uniYears; a++) {
      t = a - o.childAge; pays.push({ t: t, age: a, kind: 'University', cost: o.uniFee * Math.pow(1 + pct(o.uniInfl), t) });
    }
    var totalNominal = 0, pv = 0, todayTotal = 0;
    pays.forEach(function (p) { totalNominal += p.cost; pv += p.cost / Math.pow(1 + r, p.t); });
    pays.forEach(function (p) { todayTotal += (p.kind === 'School' ? o.schoolFee : o.uniFee); });
    var lastT = pays.length ? pays[pays.length - 1].t : 0, M = Math.max(1, Math.round(lastT * 12));
    var net = Math.max(0, pv - o.savings);
    var c = net * (Math.abs(im) < 1e-12 ? 1 / M : im / (1 - Math.pow(1 + im, -M)));
    // simulate balance
    var bal = o.savings, path = [], minBal = Infinity;
    var payAt = {}; pays.forEach(function (p) { payAt[Math.round(p.t * 12)] = (payAt[Math.round(p.t * 12)] || 0) + p.cost; });
    for (var m = 0; m <= M; m++) {
      if (m > 0) bal = bal * (1 + im) + c;
      if (payAt[m]) bal -= payAt[m];
      minBal = Math.min(minBal, bal);
      if (m % 12 === 0 || m === M) path.push({ t: m / 12, age: o.childAge + m / 12, balance: bal });
    }
    var byYear = pays.map(function (p) { return { age: p.age, kind: p.kind, cost: p.cost }; });
    return { pays: pays, byYear: byYear, totalNominal: totalNominal, totalToday: todayTotal, pv: pv, net: net, monthly: c, months: M,
      endBalance: bal, minBalance: minBal, path: path, savingsCoversAll: net === 0 };
  }

  /* ---------------- Used car valuator (transparent depreciation model; NOT a market price) ---------------- */
  var CONDITION = { Excellent: 1.05, Good: 1.0, Fair: 0.92, Poor: 0.80 };
  function car(o) {
    // o: newPrice, year, mileage, condition, marketAdj (percent), year0 (current year), d1, d, kmPerYear
    var age = Math.max(0, o.year0 - o.year), ageEff = Math.max(age, 0.5);
    var d1 = o.d1, d = o.d, kmpy = o.kmPerYear || 15000;
    var depFactor = Math.pow(1 - d1, Math.min(ageEff, 1)) * Math.pow(1 - d, Math.max(ageEff - 1, 0));
    var afterAge = o.newPrice * depFactor;
    var expectedKm = kmpy * ageEff, delta = o.mileage - expectedKm;
    var mAdj = Math.max(-0.25, Math.min(0.15, -0.025 * (delta / 10000)));
    var afterMileage = afterAge * (1 + mAdj);
    var cm = CONDITION[o.condition] || 1;
    var afterCond = afterMileage * cm;
    var afterMkt = afterCond * (1 + (o.marketAdj || 0) / 100);
    var floor = o.newPrice * 0.08;
    var est = Math.max(afterMkt, floor);
    return { age: age, depFactor: depFactor, afterAge: afterAge, expectedKm: expectedKm, deltaKm: delta, mileageAdj: mAdj, afterMileage: afterMileage,
      condMult: cm, afterCond: afterCond, afterMkt: afterMkt, floorApplied: afterMkt < floor, estimate: est,
      low: est * 0.92, high: est * 1.08, trade: est * 0.88 };
  }
  function sum(a, k) { return a.reduce(function (s, r) { return s + r[k]; }, 0); }
  return { retirement: retirement, mortgage: mortgage, pmt: pmt, education: education, car: car, CONDITION: CONDITION, mEff: mEff };
});
