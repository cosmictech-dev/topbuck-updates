/* TopBuck live feeds loader — reads /data/*.json written by the server fetcher.
   No API keys in the browser. Falls back to last-good JSON; never invents "example" numbers as real. */
(function () {
  var D = window.TB_DATA;
  if (!D) return;
  D.live = { fx: null, markets: null, news: null, ready: false, status: {} };

  function get(url) {
    return fetch(url, { cache: 'no-store', credentials: 'same-origin' }).then(function (r) {
      if (!r.ok) throw new Error(url + ' HTTP ' + r.status);
      return r.json();
    });
  }

  function fmtAsOf(iso) {
    if (!iso) return '';
    try {
      var d = new Date(iso);
      return d.toLocaleString('en-GB', { timeZone: 'Africa/Johannesburg', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' Africa/Johannesburg';
    } catch (e) { return String(iso); }
  }

  function applyFx(fx) {
    if (!fx || !fx.pairs || !fx.pairs.length) return false;
    D.live.fx = fx;
    D.fx = fx.pairs.map(function (p) {
      return { id: p.id, name: p.name, last: p.last, chg: p.chg == null ? 0 : p.chg, seed: p.seed || 21 };
    });
    if (fx.toZAR) {
      if (fx.toZAR.BWP != null) D.ccy.BWP.toZAR = fx.toZAR.BWP;
      if (fx.toZAR.ZAR != null) D.ccy.ZAR.toZAR = fx.toZAR.ZAR;
      if (fx.toZAR.NAD != null) D.ccy.NAD.toZAR = fx.toZAR.NAD;
    }
    D.asOf = fmtAsOf(fx.asOf || fx.providerUpdated) || D.asOf;
    D.live.status.fx = fx.status || 'ok';
    D.live.fxMeta = { attribution: fx.attribution, attributionUrl: fx.attributionUrl, disclaimer: fx.disclaimer, asOf: fx.asOf, status: fx.status };
    return true;
  }

  function applyMarkets(m) {
    if (!m) return false;
    D.live.markets = m;
    D.live.status.markets = m.status || 'ok';
    D.live.marketsMeta = {
      attribution: m.attribution, attributionUrl: m.attributionUrl,
      disclaimer: m.disclaimer, jseDelayNote: m.jseDelayNote,
      asOf: m.asOf, status: m.status
    };
    if (m.indices && m.indices.length) {
      D.indices = m.indices.map(function (i) {
        return {
          id: i.id, name: i.name, mkt: i.mkt, last: i.last, chg: i.chg == null ? 0 : i.chg, seed: i.seed || 11,
          note: i.note || 'Delayed / indicative',
          updatedAt: i.updatedAt || i.asOf || null,
          asOf: i.asOf || i.updatedAt || null
        };
      });
    } else if (m.status) {
      // Feed responded — do not keep static prototype index levels on screen
      D.indices = [];
    }
    if (m.movers && m.movers.length) D.movers = m.movers;
    else if (m.status) D.movers = [];
    if (m.rates && m.rates.length) {
      D.rates = m.rates.filter(function (r) {
        var id = String(r.id || ''), name = String(r.name || '').toLowerCase(), src = String(r.source || '').toLowerCase();
        if (id.indexOf('mopr') === 0) return false;
        if (src.indexOf('bank of botswana') >= 0) return false;
        if (name.indexOf('bank of botswana') >= 0 || name.indexOf('bob monetary') >= 0) return false;
        return true;
      }).map(function (r) {
        return { id: r.id, name: r.name, last: r.last, unit: r.unit || '%', note: r.note || ((r.source || '') + (r.asOf ? ' · as of ' + r.asOf : '')) };
      });
      // Sync country policy presets when live/manual rates present
      m.rates.forEach(function (r) {
        if (r.id === 'repo-za' && D.country.ZA) { D.country.ZA.policy = r.last; }
        if (r.id === 'prime-za' && D.country.ZA) { D.country.ZA.prime = r.last; D.country.ZA.mortgage = r.last; }
                if (r.id === 'repo-na' && D.country.NA) { D.country.NA.policy = r.last; }
        if (r.id === 'cpi-za' && D.country.ZA) { D.country.ZA.cpiNow = r.last; D.country.ZA.infl = r.last; }
        if (r.id === 'cpi-bw' && D.country.BW) { D.country.BW.cpiNow = r.last; }
        if (r.id === 'cpi-na' && D.country.NA) { D.country.NA.cpiNow = r.last; }
      });
    }
    // Commodities: clear example board when live mode — do not present invented numbers as real
    if (m.status && m.status !== 'unavailable') {
      D.commodities = Array.isArray(m.commodities) ? m.commodities : [];
    }
    if (m.asOf) D.asOf = fmtAsOf(m.asOf);
    return true;
  }

  function applyNews(n) {
    if (!n) return false;
    D.live.news = n;
    D.live.status.news = n.status || 'ok';
    D.live.newsMeta = { attribution: n.attribution, attributionUrl: n.attributionUrl, disclaimer: n.disclaimer, asOf: n.asOf, status: n.status };
    if (n.items && n.items.length) {
      // Keep any local insight drafts that are not example placeholders? Soft launch: replace news-type only, drop example news.
      var insights = (D.news || []).filter(function (x) { return x.type === 'insight' && !(x.author || '').toLowerCase().includes('example'); });
      // If all insights were examples, drop them too so we don't mix fake with live
      if (!insights.length) insights = [];
      D.news = insights.concat(n.items.map(function (it) {
        return {
          id: it.id, type: 'news', cat: it.cat || 'News', title: it.title, dek: it.dek || '',
          date: it.date || '', author: it.author || '', url: it.url, external: true, mins: it.mins || 1
        };
      }));
    }
    return true;
  }

  function stampDemoBar() {
    var bar = document.querySelector('.demo-bar');
    if (!bar) return;
    var parts = [];
    var fx = D.live.status.fx, mk = D.live.status.markets, nw = D.live.status.news;
    if (fx === 'ok' || fx === 'partial' || fx === 'stale') parts.push('FX live');
    if (mk === 'ok' || mk === 'partial' || mk === 'stale') parts.push('markets delayed/indicative');
    if (nw === 'ok' || nw === 'partial' || nw === 'stale') parts.push('news headlines');
    var stale = [fx, mk, nw].indexOf('stale') >= 0;
    bar.innerHTML = '<b>LIVE DATA</b> — ' + (parts.length ? parts.join(' · ') : 'feeds loading') +
      (stale ? ' · <b>showing last good data</b>' : '') +
      ' · informational only, not advice. As of ' + (D.asOf || '—') + '.';
  }

  window.TB_FEEDS = {
    asOfText: fmtAsOf,
    meta: function () { return { fx: D.live.fxMeta, markets: D.live.marketsMeta, news: D.live.newsMeta }; },
    status: function () { return D.live.status; }
  };

  var readyResolve;
  window.TB_FEEDS_READY = new Promise(function (res) { readyResolve = res; });

  Promise.allSettled([
    get('data/fx.json'),
    get('data/markets.json'),
    get('data/news.json')
  ]).then(function (results) {
    if (results[0].status === 'fulfilled') applyFx(results[0].value);
    if (results[1].status === 'fulfilled') applyMarkets(results[1].value);
    if (results[2].status === 'fulfilled') applyNews(results[2].value);
    D.live.ready = true;
    D.version = 'live-feeds-0.1';
    // Strip prototype example marker from asOf if we got anything live
    if (D.live.fxMeta || D.live.marketsMeta || D.live.newsMeta) {
      if (String(D.asOf).indexOf('example') >= 0) D.asOf = fmtAsOf((D.live.fxMeta || D.live.marketsMeta || {}).asOf) || D.asOf;
    }
    stampDemoBar();
    readyResolve(D.live);
    document.dispatchEvent(new CustomEvent('tb:feeds', { detail: D.live }));
  }).catch(function () {
    D.live.ready = true;
    readyResolve(D.live);
    document.dispatchEvent(new CustomEvent('tb:feeds', { detail: D.live }));
  });
})();
