document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart, q = new URLSearchParams(location.search);
  var type = 'news', cat = 'All', text = '';
  var tabs = [['news', 'News']];
  var meta = (window.TB_FEEDS && TB_FEEDS.meta().news) || {};

  function liveOk(st) { return st === 'ok' || st === 'partial' || st === 'stale'; }
  function newsLive() {
    return liveOk(meta.status || (D.live && D.live.status && D.live.status.news)) && D.news.some(function (n) { return n.type === 'news' && n.external; });
  }
  function show(sel, on) { document.querySelectorAll(sel).forEach(function (el) { el.hidden = !on; }); }

  function applyLabels() {
    var live = newsLive();
    var eyebrow = document.getElementById('n-eyebrow');
    if (eyebrow) eyebrow.textContent = live ? 'Headlines & links' : 'News';
    var ex = document.getElementById('n-ex-tag');
    if (ex) ex.hidden = true; // never slap Example over empty; use coming-soon
    show('.feed-live-news', live);
    var soon = document.getElementById('n-soon');
    if (soon) soon.hidden = live;
    var stEl = document.getElementById('n-status');
    if (stEl) {
      stEl.textContent = live
        ? ('Feed: ' + (meta.status || 'ok') + (meta.asOf ? ' · as of ' + TB_FEEDS.asOfText(meta.asOf) : ''))
        : 'Live headlines coming soon (Currents API key required).';
    }
  }

  function hrefFor(n) {
    if (n.external && n.url) return n.url;
    return 'article.html?id=' + encodeURIComponent(n.id);
  }
  function targetFor(n) { return (n.external && n.url) ? ' target="_blank" rel="noopener noreferrer"' : ''; }

  function drawTabs() { document.getElementById('ntabs').innerHTML = tabs.map(function (t) { return '<button type="button" data-t="' + t[0] + '" aria-pressed="' + (t[0] === type) + '">' + t[1] + '</button>'; }).join(''); }
  function drawCats() {
    var cats = ['All'].concat(Array.from(new Set(D.news.filter(function (n) { return n.type === 'news'; }).map(function (n) { return n.cat; }))));
    document.getElementById('ncats').innerHTML = cats.map(function (c) { return '<button type="button" class="chip' + (c === cat ? ' on' : '') + '" data-c="' + c + '">' + c + '</button>'; }).join('');
  }
  function list() {
    var items = D.news.filter(function (n) {
      return (type === 'all' || n.type === type) && (cat === 'All' || n.cat === cat) && (!text || (n.title + (n.dek || '') + n.cat).toLowerCase().indexOf(text) >= 0);
    });
    document.getElementById('nlist').innerHTML = items.length ? items.map(function (n) {
      var href = hrefFor(n), tgt = targetFor(n);
      var tag = n.external ? 'Headline' : (n.type === 'insight' ? 'Insight' : 'News');
      return '<article class="card hover news-card"><a class="news-thumb" href="' + href + '"' + tgt + ' aria-label="' + C.esc(n.title) + '"></a>' +
        '<div class="meta"><span class="tag">' + C.esc(n.cat) + '</span><span class="tag">' + tag + '</span></div>' +
        '<h3><a href="' + href + '"' + tgt + '>' + C.esc(n.title) + '</a></h3>' +
        '<p class="small muted" style="margin:0">' + C.esc(n.dek || '') + '</p>' +
        '<div class="meta" style="margin-top:auto">' + C.esc(n.date || '') + ' · ' + C.esc(n.author || '') +
        (n.external ? ' · <a href="' + href + '"' + tgt + '>Read at publisher</a>' : '') + '</div></article>';
    }).join('') : '<p class="muted">' + (newsLive() ? 'No headlines match your filters.' : 'Live headlines coming soon — Currents API key not configured yet.') + '</p>';
  }
  applyLabels(); drawTabs(); drawCats(); list();
  document.getElementById('ntabs').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; type = b.dataset.t; drawTabs(); list(); });
  document.getElementById('ncats').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; cat = b.dataset.c; drawCats(); list(); });
  document.getElementById('nq').addEventListener('input', function (e) { text = e.target.value.toLowerCase(); list(); });
});
