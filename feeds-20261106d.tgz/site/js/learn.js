document.addEventListener('tb:ready', function () {
  var links = { Basics: 'retirement.html', Property: 'mortgage.html', Retirement: 'retirement.html', Education: 'education.html', Motoring: 'car-valuator.html', Compliance: 'about.html#compliance' };
  document.getElementById('learn').innerHTML = TB_DATA.learn.map(function (g, i) { return '<a class="card hover news-card" style="color:inherit" href="' + links[g.k] + '"><div class="news-thumb">' + TBChart.thumb(40 + i * 9, g.k) + '</div><div class="meta"><span class="tag">' + g.k + '</span><span>' + g.m + ' min</span></div><h3>' + g.t + '</h3><span class="small" style="color:var(--gold-400);font-weight:700">Read &amp; try the tool →</span></a>'; }).join('');
});
