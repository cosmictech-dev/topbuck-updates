document.addEventListener('tb:ready', function () {
  var C = TBChart, K = TB.kpi;
  TB.calc({
    type: 'education', fields: { childAge: 'childAge', schoolStartAge: 'schoolStart', schoolYears: 'schoolYears', schoolFee: 'schoolFee', schoolInfl: 'schoolInfl', uniStartAge: 'uniStart', uniYears: 'uniYears', uniFee: 'uniFee', uniInfl: 'uniInfl', savings: 'savings', ret: 'ret' },
    label: function (p) { return 'Child age ' + p.childAge + ' — school + ' + p.uniYears + '-yr uni'; },
    valid: function (p) { if (!(p.uniStartAge >= p.schoolStartAge + p.schoolYears - 1)) return 'University should start after school ends.'; if (!(p.childAge >= 0)) return 'Enter the child’s age.'; return true; },
    run: function (p) {
      var r = TBCalc.education(p);
      document.getElementById('kpis').innerHTML = K('Total projected fees', TB.fmt(r.totalNominal)) + K('Same fees in today’s money', TB.fmt(r.totalToday)) + K('Monthly saving target', TB.fmt(r.monthly), true) +
        K('Present value of fees', TB.fmt(r.pv)) + K('Saved already', TB.fmt(p.savings)) + K('Months to fund', r.months);
      var school = r.byYear.filter(function (x) { return x.kind === 'School'; }).reduce(function (s, x) { return s + x.cost; }, 0), uni = r.totalNominal - school;
      document.getElementById('verdict').innerHTML = (r.savingsCoversAll ? '<span class="pill ok">Existing savings cover the plan</span> ' : '') + '<span class="small muted">School ' + TB.fmt(school) + ' · University ' + TB.fmt(uni) + (r.minBalance < -1 ? ' · The balance dips to ' + TB.fmt(r.minBalance) + ' in early years, so some fees would come from cash flow.' : '') + '</span>';
      var ages = r.byYear.map(function (x) { return x.age; });
      C.columns(document.getElementById('chart'), { cats: ages, stacks: [{ name: 'School', color: '#D6AA4B', vals: r.byYear.map(function (x) { return x.kind === 'School' ? x.cost : 0; }) }, { name: 'University', color: '#F3ECDB', vals: r.byYear.map(function (x) { return x.kind === 'University' ? x.cost : 0; }) }], yFmt: function (v) { return TB.compact(v); }, tipFmt: function (v) { return TB.fmt(v); }, xFmt: function (c) { return 'Age ' + c; }, label: 'Projected fees by age' });
      C.line(document.getElementById('chart2'), { series: [{ name: 'Savings balance', color: '#D6AA4B', area: true, pts: r.path.map(function (x) { return [x.age, x.balance]; }) }], yMin: Math.min(0, r.minBalance * 1.1), xFmt: function (x) { return 'Age ' + x.toFixed(0); }, yFmt: function (v) { return TB.compact(v); }, tipFmt: function (v) { return TB.fmt(v); }, label: 'Savings balance' });
      document.getElementById('tbl').innerHTML = '<thead><tr><th>Child’s age</th><th>Stage</th><th>Fee that year</th></tr></thead><tbody>' + r.byYear.map(function (x) { return '<tr><td>' + x.age + '</td><td>' + x.kind + '</td><td>' + TB.fmt(x.cost) + '</td></tr>'; }).join('') + '<tr><td><b>Total</b></td><td></td><td><b>' + TB.fmt(r.totalNominal) + '</b></td></tr></tbody>';
    }
  });
});
