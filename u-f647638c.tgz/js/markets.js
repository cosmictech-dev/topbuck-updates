document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart, tab = 'indices', sel = null, range = 90;
  var groups = { indices: ['Indices', D.indices], fx: ['Currencies', D.fx], commodities: ['Commodities', D.commodities] };
  function series(i, n) { var raw = D.series(i.seed, n, 100, i.id.indexOf('fx') > -1 ? 0.006 : 0.014, i.chg >= 0 ? 0.0012 : -0.0006); var k = i.last / raw[n - 1]; return raw.map(function (v) { return v * k; }); }
  function table() {
    var g = groups[tab], th = '<thead><tr><th>Name</th><th>Last</th><th>Change</th><th>30-day</th></tr></thead>';
    document.getElementById('mtable').innerHTML = th + '<tbody>' + g[1].map(function (i) { return '<tr class="sel" data-id="' + i.id + '" style="cursor:pointer;' + (sel && sel.id === i.id ? 'background:rgba(214,170,75,.08)' : '') + '"><td><b>' + i.name + '</b></td><td>' + TB.group(i.last, i.last >= 100 ? 1 : 2) + '</td><td>' + TB.chg(i.chg) + '</td><td>' + C.spark(series(i, 30), i.chg >= 0 ? '#58C28A' : '#E4796B') + '</td></tr>'; }).join('') + '</tbody>';
  }
  function chart() {
    var s = series(sel, range), pts = s.map(function (v, i) { return [i - range + 1, v]; });
    document.getElementById('mtitle').textContent = sel.name + ' — example price path';
    C.line(document.getElementById('mchart'), { series: [{ name: sel.name, color: '#D6AA4B', pts: pts, area: true }], yMin: Math.min.apply(null, s) * 0.97, yFmt: function (v) { return TB.group(v, v >= 100 ? 0 : 2); }, xFmt: function (x) { return x === 0 ? 'Today' : Math.round(-x) + 'd ago'; }, tipFmt: function (v) { return TB.group(v, v >= 100 ? 1 : 3); }, label: 'Example price path' });
  }
  function tabs() { document.getElementById('mtabs').innerHTML = Object.keys(groups).map(function (k) { return '<button type="button" data-k="' + k + '" aria-pressed="' + (k === tab) + '">' + groups[k][0] + '</button>'; }).join(''); }
  function ranges() { document.getElementById('mrange').innerHTML = [['1M', 30], ['3M', 90], ['1Y', 250]].map(function (r) { return '<button type="button" data-r="' + r[1] + '" aria-pressed="' + (r[1] === range) + '">' + r[0] + '</button>'; }).join(''); }
  sel = groups[tab][1][0]; tabs(); ranges(); table(); chart();
  document.getElementById('mtabs').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; tab = b.dataset.k; sel = groups[tab][1][0]; tabs(); table(); chart(); });
  document.getElementById('mtable').addEventListener('click', function (e) { var tr = e.target.closest('tr[data-id]'); if (!tr) return; sel = groups[tab][1].filter(function (i) { return i.id === tr.dataset.id; })[0]; table(); chart(); });
  document.getElementById('mrange').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; range = +b.dataset.r; ranges(); chart(); });
  document.getElementById('movers').innerHTML = D.movers.map(function (m) { return '<div class="mkt-row"><div><div class="nm">' + m.name + '</div><div class="sub">' + m.mkt + '</div></div><div class="num">' + TB.group(m.last, 2) + '</div><div>' + TB.chg(m.chg) + '</div></div>'; }).join('');
  document.getElementById('rates').innerHTML = '<thead><tr><th>Rate</th><th>Level</th></tr></thead><tbody>' + D.rates.map(function (r) { return '<tr><td>' + r.name + '<div class="small muted">' + r.note + '</div></td><td><b>' + r.last.toFixed(2) + r.unit + '</b></td></tr>'; }).join('') + '</tbody>';
});
