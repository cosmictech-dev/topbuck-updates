/* TopBuck prototype — EXAMPLE DATA ONLY. Nothing here is real market data, news, client data or a rate quote. */
window.TB_DATA = (function () {
  var D = {};
  D.version = 'prototype-0.1';
  D.asOf = '3 Nov 2026 (example)';
  // FX to ZAR (illustrative). NAD is pegged 1:1 to ZAR. BWP is a basket-managed crawling peg.
  D.ccy = {
    BWP: { code: 'BWP', sym: 'P',  name: 'Botswana pula',     toZAR: 1.32, country: 'BW', locale: 'en-BW' },
    ZAR: { code: 'ZAR', sym: 'R',  name: 'South African rand', toZAR: 1.00, country: 'ZA', locale: 'en-ZA' },
    NAD: { code: 'NAD', sym: 'N$', name: 'Namibia dollar',     toZAR: 1.00, country: 'NA', locale: 'en-NA' }
  };
  // Country assumption presets — illustrative starting points, NOT quotes. Verify against central bank / bank / fund sources.
  D.country = {
    BW: { name: 'Botswana', policyLabel: 'BoB Monetary Policy Rate', policy: 5.50, prime: 7.75, mortgage: 8.50, cpiNow: 7.8, infl: 5.0,
          preRet: 9.0, postRet: 7.0, schoolInfl: 6.0, uniInfl: 6.0, retNote: 'Example: BPOPF-style DC fund — 15% employer + 5% member of pensionable salary (verify with fund). Lump-sum share varies by fund rules.',
          lumpPct: 50, regs: 'NBFIRA / Retirement Funds Act 2022' },
    ZA: { name: 'South Africa', policyLabel: 'SARB repo rate', policy: 7.25, prime: 10.75, mortgage: 10.75, cpiNow: 4.5, infl: 4.5,
          preRet: 10.0, postRet: 7.5, schoolInfl: 7.0, uniInfl: 6.0, retNote: 'Two-pot: from 1 Sep 2024, one-third of new contributions go to a savings pot, two-thirds to a retirement pot. Regulation 28 caps equity at 75%, property 25% and offshore at 45%.',
          lumpPct: 33, regs: 'FSCA / Pension Funds Act / Reg 28' },
    NA: { name: 'Namibia', policyLabel: 'BoN repo rate', policy: 7.00, prime: 10.50, mortgage: 10.50, cpiNow: 5.4, infl: 4.5,
          preRet: 9.5, postRet: 7.5, schoolInfl: 6.5, uniInfl: 6.0, retNote: 'Example: Namibian pension funds are regulated by NAMFISA; the ZAR-linked market means offshore/ZAR exposure is common.',
          lumpPct: 33, regs: 'NAMFISA' }
  };
  // seeded PRNG so charts/sparklines are stable
  function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; var t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };
  D.series = function (seed, n, start, vol, drift) {
    var r = rng(seed), v = start, out = [];
    for (var i = 0; i < n; i++) { v = v * (1 + (r() - 0.5) * vol + (drift || 0)); out.push(v); }
    // scale so the final point equals the stated last value (set by caller)
    return out;
  };
  D.indices = [
    { id: 'jse-all', name: 'JSE All Share', mkt: 'ZA', last: 112480.2, chg: 0.62, seed: 11, note: 'Example level' },
    { id: 'jse-t40', name: 'JSE Top 40', mkt: 'ZA', last: 103915.7, chg: 0.55, seed: 12, note: 'Example level' },
    { id: 'bse-dci', name: 'BSE Domestic Company Index', mkt: 'BW', last: 8021.4, chg: 0.18, seed: 13, note: 'Example level' },
    { id: 'nsx-ov', name: 'NSX Overall Index', mkt: 'NA', last: 1648.9, chg: -0.21, seed: 14, note: 'Example level' },
    { id: 'sp500', name: 'S&P 500', mkt: 'US', last: 6120.5, chg: 0.31, seed: 15, note: 'Example level' },
    { id: 'ftse', name: 'FTSE 100', mkt: 'UK', last: 8654.3, chg: -0.12, seed: 16, note: 'Example level' }
  ];
  D.fx = [
    { id: 'usdzar', name: 'USD / ZAR', last: 17.82, chg: -0.28, seed: 21 },
    { id: 'usdbwp', name: 'USD / BWP', last: 13.49, chg: -0.10, seed: 22 },
    { id: 'usdnad', name: 'USD / NAD', last: 17.82, chg: -0.28, seed: 23 },
    { id: 'eurzar', name: 'EUR / ZAR', last: 20.64, chg: 0.09, seed: 24 },
    { id: 'gbpzar', name: 'GBP / ZAR', last: 23.71, chg: 0.15, seed: 25 },
    { id: 'bwpzar', name: 'BWP / ZAR', last: 1.32, chg: 0.02, seed: 26 }
  ];
  D.commodities = [
    { id: 'gold', name: 'Gold (USD/oz)', last: 2864.0, chg: 0.74, seed: 31 },
    { id: 'plat', name: 'Platinum (USD/oz)', last: 1021.5, chg: -0.35, seed: 32 },
    { id: 'brent', name: 'Brent crude (USD/bbl)', last: 82.4, chg: 1.1, seed: 33 },
    { id: 'diamond', name: 'Rough diamond index (rebased)', last: 96.2, chg: -0.4, seed: 34 }
  ];
  D.rates = [
    { id: 'repo-za', name: 'SARB repo rate', last: 7.25, unit: '%', note: 'Example; next MPC meeting shown on SARB calendar' },
    { id: 'prime-za', name: 'SA prime lending rate', last: 10.75, unit: '%', note: 'Example' },
    { id: 'mopr-bw', name: 'BoB Monetary Policy Rate', last: 5.50, unit: '%', note: 'Example' },
    { id: 'repo-na', name: 'BoN repo rate', last: 7.00, unit: '%', note: 'Example' },
    { id: 'cpi-za', name: 'SA headline CPI (y/y)', last: 4.5, unit: '%', note: 'Example' },
    { id: 'cpi-bw', name: 'Botswana headline CPI (y/y)', last: 7.8, unit: '%', note: 'Example' },
    { id: 'cpi-na', name: 'Namibia headline CPI (y/y)', last: 5.4, unit: '%', note: 'Example' }
  ];
  D.movers = [
    { name: 'Example Mining Ltd', mkt: 'JSE', last: 184.2, chg: 4.1 }, { name: 'Example Retail Group', mkt: 'JSE', last: 96.5, chg: 2.7 },
    { name: 'Example Telecom Holdings', mkt: 'BSE', last: 3.18, chg: 1.9 }, { name: 'Example Brewing Co', mkt: 'JSE', last: 241.0, chg: -2.2 },
    { name: 'Example Bank Namibia', mkt: 'NSX', last: 58.4, chg: -1.6 }, { name: 'Example Insurance Ltd', mkt: 'BSE', last: 6.42, chg: -0.9 }
  ];
  // Example articles — fictional, for layout only
  D.news = [
    { id: 'n1', type: 'insight', cat: 'Retirement', title: 'Two-pot at two years: what advisors are seeing in client behaviour', mins: 6, date: '3 Nov 2026', author: 'TopBuck Editorial (example)',
      dek: 'An illustrative look at how savings-pot withdrawals change retirement projections — and how to show clients the trade-off.',
      body: ['This is an example article written to demonstrate TopBuck’s layout. It is not a real news report and contains no verified market claims.',
        'Savings-component withdrawals are taxed at the member’s marginal rate and cannot be reversed. A projection that shows the same client with and without a withdrawal makes the long-term cost visible in rand, pula or dollars.',
        'In the TopBuck retirement calculator, switch on the two-pot view to split the projected balance into vested, savings and retirement pots, then save the scenario to your client book.'],
      callout: 'Example insight. Replace with licensed editorial or original analysis before launch.' },
    { id: 'n2', type: 'news', cat: 'Markets', title: 'Example: JSE closes higher as miners lead gains', mins: 3, date: '3 Nov 2026', author: 'Example newswire',
      dek: 'Illustrative market wrap for prototype purposes only.',
      body: ['Example copy only. Index levels and company names in this prototype are invented.', 'In production, a market wrap like this would be sourced from a licensed newswire and tagged with the instruments it mentions, linking through to the relevant quote pages.'], callout: 'Example data — not a real market report.' },
    { id: 'n3', type: 'news', cat: 'Economy', title: 'Example: Rate decisions in the SACU region — what the calendar looks like', mins: 4, date: '2 Nov 2026', author: 'Example newswire',
      dek: 'A calendar-style explainer showing how central bank decisions flow into prime rates and home-loan repayments.',
      body: ['Example only. Central banks in Botswana, South Africa and Namibia each publish a decision calendar; TopBuck would pull these dates into a single rates calendar.', 'When the repo or policy rate moves, banks set their own prime lending rates. Use the mortgage calculator to test how a 0.25% change alters a monthly instalment.'], callout: 'Example copy. Check each central bank’s site for real decision dates.' },
    { id: 'n4', type: 'insight', cat: 'Property', title: 'How much house can R1.5m of income actually buy? A worked example', mins: 7, date: '1 Nov 2026', author: 'TopBuck Editorial (example)',
      dek: 'Worked mortgage maths with a 30% repayment-to-income rule of thumb and the effect of extra payments.',
      body: ['This worked example is illustrative. Banks apply their own affordability criteria.', 'Take a bond of R1,800,000 over 20 years at 10.75% nominal: the instalment is about R18,300 a month. An extra R1,000 a month shortens the term by several years and saves a six-figure sum in interest.', 'Try your own numbers in the mortgage calculator and download the schedule as a report.'], callout: 'Illustrative numbers.' },
    { id: 'n5', type: 'news', cat: 'Motoring', title: 'Example: Used-vehicle prices ease as new-model discounts widen', mins: 3, date: '31 Oct 2026', author: 'Example newswire',
      dek: 'Prototype copy to show the motoring category.',
      body: ['Example only. Real used-vehicle pricing comes from licensed sources such as dealer guides and listing data; the TopBuck valuator in this prototype uses a transparent depreciation model and labels its output as an estimate.'], callout: 'Example copy.' },
    { id: 'n6', type: 'insight', cat: 'Education', title: 'School fees outrun CPI: planning for 12 years of increases', mins: 5, date: '30 Oct 2026', author: 'TopBuck Editorial (example)',
      dek: 'Why education inflation deserves its own assumption in a financial plan.',
      body: ['Education costs have tended to rise faster than headline CPI in the region. In a plan, use separate school-fee and tertiary-fee inflation assumptions.', 'The education fees calculator turns a child’s age and today’s fee into a projected cost for every year and a monthly savings target.'], callout: 'Example commentary.' },
    { id: 'n7', type: 'news', cat: 'Regulation', title: 'Example: Regulators remind firms on digital advice disclosures', mins: 3, date: '29 Oct 2026', author: 'Example newswire',
      dek: 'Illustrative regulatory news item.',
      body: ['Example copy. Digital tools that move from information to recommendations may fall within advice regulation. TopBuck labels calculators as information and routes personalised recommendations to authorised advisors.'], callout: 'Not legal advice — example copy.' },
    { id: 'n8', type: 'insight', cat: 'Markets', title: 'Reading the pula: a primer on the basket crawl and what it means for offshore returns', mins: 6, date: '28 Oct 2026', author: 'TopBuck Editorial (example)',
      dek: 'Currency primer for Botswana-based investors with offshore allocations.',
      body: ['Example explainer. The pula is managed against a basket of currencies, so its moves against the rand and dollar differ from a floating currency.', 'When projecting offshore returns, state clearly whether numbers are in pula, rand or dollars.'], callout: 'Example primer.' },
    { id: 'n9', type: 'news', cat: 'Retirement', title: 'Example: Fund fees under the spotlight — what to ask your administrator', mins: 4, date: '27 Oct 2026', author: 'Example newswire',
      dek: 'Illustrative item on retirement fund costs.', body: ['Example copy only. A 1% difference in annual fees compounds to a large difference over 30 years; TopBuck’s retirement calculator accepts a net-of-fee return so the effect can be tested.'], callout: 'Example copy.' },
    { id: 'n10', type: 'insight', cat: 'Tax & Policy', title: 'Retirement-fund tax deduction limits: a one-page client explainer', mins: 5, date: '26 Oct 2026', author: 'TopBuck Editorial (example)',
      dek: 'A short template advisors can adapt for client conversations.', body: ['Example explainer. Contribution deduction limits and lump-sum tax tables change; always cite the current revenue authority tables. This page is a layout demo.'], callout: 'Check SARS, BURS and NamRA for current rules.' }
  ];
  D.learn = [
    { t: 'Compound interest in plain language', k: 'Basics', m: 4 }, { t: 'How a home loan really works', k: 'Property', m: 6 }, { t: 'What is Regulation 28?', k: 'Retirement', m: 5 },
    { t: 'Education inflation explained', k: 'Education', m: 4 }, { t: 'Depreciation: what happens to a car’s value', k: 'Motoring', m: 5 }, { t: 'Advice vs information: what clients should know', k: 'Compliance', m: 4 }
  ];
  // Example clients (invented). ccy = client's home currency. Scenario params are in that currency.
  D.clients = [
    { id: 'c1', name: 'Thandi Moloi', age: 41, ccy: 'ZAR', aum: 2850000, risk: 'Moderate', review: '12 Oct 2026', status: 'On track', goal: 68, tag: 'Retirement', email: 'thandi@example.com' },
    { id: 'c2', name: 'Kabelo Seretse', age: 36, ccy: 'BWP', aum: 640000, risk: 'Moderately aggressive', review: '29 Sep 2026', status: 'Review due', goal: 44, tag: 'Home loan', email: 'kabelo@example.com' },
    { id: 'c3', name: 'Anneli Shikongo', age: 49, ccy: 'NAD', aum: 4120000, risk: 'Moderate', review: '03 Oct 2026', status: 'On track', goal: 81, tag: 'Retirement', email: 'anneli@example.com' },
    { id: 'c4', name: 'Pieter van Wyk', age: 33, ccy: 'ZAR', aum: 410000, risk: 'Aggressive', review: '21 Aug 2026', status: 'Review due', goal: 29, tag: 'Education', email: 'pieter@example.com' },
    { id: 'c5', name: 'Naledi Dube', age: 54, ccy: 'BWP', aum: 3380000, risk: 'Conservative', review: '15 Oct 2026', status: 'On track', goal: 90, tag: 'Retirement', email: 'naledi@example.com' },
    { id: 'c6', name: 'Joseph Haufiku', age: 29, ccy: 'NAD', aum: 185000, risk: 'Aggressive', review: '07 Sep 2026', status: 'Needs attention', goal: 18, tag: 'Vehicle', email: 'joseph@example.com' },
    { id: 'c7', name: 'Lerato Nkosi', age: 45, ccy: 'ZAR', aum: 1960000, risk: 'Moderate', review: '26 Oct 2026', status: 'On track', goal: 57, tag: 'Education', email: 'lerato@example.com' },
    { id: 'c8', name: 'Tshepo Kgosi', age: 38, ccy: 'BWP', aum: 920000, risk: 'Moderate', review: '30 Sep 2026', status: 'Review due', goal: 51, tag: 'Home loan', email: 'tshepo@example.com' }
  ];
  D.scenarios = [
    { id: 's1', client: 'c1', type: 'retirement', label: 'Retire at 63, R35k target', date: '12 Oct 2026', ccy: 'ZAR', params: { age: 41, retAge: 63, planAge: 90, savings: 1450000, monthly: 9500, escal: 5, preRet: 10, postRet: 7.5, infl: 4.5, targetIncome: 35000, salary: 62000, twoPot: true } },
    { id: 's2', client: 'c1', type: 'retirement', label: 'Retire at 65, same target', date: '12 Oct 2026', ccy: 'ZAR', params: { age: 41, retAge: 65, planAge: 90, savings: 1450000, monthly: 9500, escal: 5, preRet: 10, postRet: 7.5, infl: 4.5, targetIncome: 35000, salary: 62000, twoPot: true } },
    { id: 's3', client: 'c2', type: 'mortgage', label: 'P1.4m home, 10% deposit', date: '29 Sep 2026', ccy: 'BWP', params: { price: 1400000, depositPct: 10, rate: 8.5, years: 20, extra: 0 } },
    { id: 's4', client: 'c2', type: 'mortgage', label: 'Same, +P1,000/month extra', date: '29 Sep 2026', ccy: 'BWP', params: { price: 1400000, depositPct: 10, rate: 8.5, years: 20, extra: 1000 } },
    { id: 's5', client: 'c3', type: 'retirement', label: 'Retire at 62', date: '03 Oct 2026', ccy: 'NAD', params: { age: 49, retAge: 62, planAge: 90, savings: 3200000, monthly: 16000, escal: 5, preRet: 9.5, postRet: 7.5, infl: 4.5, targetIncome: 60000, salary: 110000, twoPot: false } },
    { id: 's6', client: 'c4', type: 'education', label: 'Daughter, age 4 — private school + uni', date: '21 Aug 2026', ccy: 'ZAR', params: { childAge: 4, schoolStartAge: 6, schoolYears: 12, schoolFee: 75000, schoolInfl: 7, uniStartAge: 18, uniYears: 3, uniFee: 70000, uniInfl: 6, savings: 15000, ret: 9 } },
    { id: 's7', client: 'c5', type: 'retirement', label: 'Retire at 60 (BPOPF-style DC)', date: '15 Oct 2026', ccy: 'BWP', params: { age: 54, retAge: 60, planAge: 88, savings: 2900000, monthly: 12000, escal: 3, preRet: 9, postRet: 7, infl: 5, targetIncome: 22000, salary: 48000, twoPot: false } },
    { id: 's8', client: 'c6', type: 'car', label: 'Used Hilux — trade-in check', date: '07 Sep 2026', ccy: 'NAD', params: { model: 'hilux', year: 2020, mileage: 118000, condition: 'Good', marketAdj: 0 } },
    { id: 's9', client: 'c7', type: 'education', label: 'Son, age 9', date: '26 Oct 2026', ccy: 'ZAR', params: { childAge: 9, schoolStartAge: 6, schoolYears: 12, schoolFee: 58000, schoolInfl: 7, uniStartAge: 18, uniYears: 4, uniFee: 82000, uniInfl: 6, savings: 60000, ret: 9 } },
    { id: 's10', client: 'c8', type: 'mortgage', label: 'P2.1m home, 15 years', date: '30 Sep 2026', ccy: 'BWP', params: { price: 2100000, depositPct: 15, rate: 8.5, years: 15, extra: 0 } }
  ];
  // Car models — illustrative list prices in ZAR (NOT manufacturer or dealer prices) and segment depreciation assumptions.
  D.cars = [
    { id: 'hilux', make: 'Toyota', model: 'Hilux 2.4 GD-6 double cab', newZAR: 640000, d1: 0.12, d: 0.08, seg: 'Bakkie' },
    { id: 'ranger', make: 'Ford', model: 'Ranger 2.0 BiT double cab', newZAR: 850000, d1: 0.15, d: 0.09, seg: 'Bakkie' },
    { id: 'dmax', make: 'Isuzu', model: 'D-Max 1.9 double cab', newZAR: 590000, d1: 0.14, d: 0.09, seg: 'Bakkie' },
    { id: 'fortuner', make: 'Toyota', model: 'Fortuner 2.8 GD-6', newZAR: 830000, d1: 0.12, d: 0.08, seg: 'SUV' },
    { id: 'corolla-cross', make: 'Toyota', model: 'Corolla Cross 1.8 XS', newZAR: 440000, d1: 0.13, d: 0.09, seg: 'SUV' },
    { id: 'polo', make: 'Volkswagen', model: 'Polo 1.0 TSI', newZAR: 365000, d1: 0.17, d: 0.10, seg: 'Hatchback' },
    { id: 'swift', make: 'Suzuki', model: 'Swift 1.2 GL', newZAR: 245000, d1: 0.14, d: 0.09, seg: 'Hatchback' },
    { id: 'i20', make: 'Hyundai', model: 'i20 1.2 Motion', newZAR: 295000, d1: 0.16, d: 0.10, seg: 'Hatchback' },
    { id: 'jolion', make: 'Haval', model: 'Jolion 1.5T Premium', newZAR: 460000, d1: 0.19, d: 0.11, seg: 'SUV' },
    { id: 'cx5', make: 'Mazda', model: 'CX-5 2.0 Dynamic', newZAR: 560000, d1: 0.16, d: 0.10, seg: 'SUV' },
    { id: 'navara', make: 'Nissan', model: 'Navara 2.5 DDTi double cab', newZAR: 620000, d1: 0.17, d: 0.10, seg: 'Bakkie' },
    { id: 'c200', make: 'Mercedes-Benz', model: 'C200 sedan', newZAR: 940000, d1: 0.20, d: 0.12, seg: 'Premium sedan' }
  ];
  return D;
})();
