document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart, K = TB.kpi, Y0 = 2026;
  var sel = document.getElementById('model'), ys = document.getElementById('year');
  sel.innerHTML = D.cars.map(function (c) { return '<option value="' + c.id + '">' + c.make + ' ' + c.model + '</option>'; }).join('');
  for (var y = Y0; y >= 2008; y--) ys.insertAdjacentHTML('beforeend', '<option>' + y + '</option>');
  ys.value = 2021;
  var q = new URLSearchParams(location.search), pp = {}; try { pp = JSON.parse(q.get('p') || '{}'); } catch (e) { }
  function carOf(id) { return D.cars.filter(function (c) { return c.id === id; })[0]; }
  function setModel(initial) { var c = carOf(sel.value); document.getElementById('newPrice').value = TB.nice(TB.convert(c.newZAR, 'ZAR', TB.ccy)); document.getElementById('d1').value = c.d1 * 100; document.getElementById('d').value = c.d * 100; }
  if (pp.model) { sel.value = pp.model; }
  setModel();
  var applied = false;
  var calc = TB.calc({
    type: 'car', fields: { model: 'model', year: 'year', mileage: 'mileage', condition: 'cond', newPrice: 'newPrice', marketAdj: 'mkt', d1: 'd1', d: 'd', kmPerYear: 'kmpy' },
    label: function (p) { var c = carOf(p.model); return c.make + ' ' + c.model.split(' ')[0] + ' ' + p.year + ' — estimate'; },
    valid: function (p) { if (!(p.newPrice > 0)) return 'Enter a reference new price.'; if (!(p.mileage >= 0)) return 'Enter the mileage.'; return true; },
    run: function (p) {
      document.getElementById('mktv').textContent = (p.marketAdj > 0 ? '+' : '') + p.marketAdj + '%';
      var args = { newPrice: p.newPrice, year: +p.year, year0: Y0, mileage: p.mileage, condition: p.condition, marketAdj: p.marketAdj, d1: p.d1 / 100, d: p.d / 100, kmPerYear: p.kmPerYear };
      var r = TBCalc.car(args), c = carOf(p.model);
      document.getElementById('kpis').innerHTML = K('Estimated value (model)', TB.fmt(r.estimate), true) + K('Likely range', TB.compact(r.low) + ' – ' + TB.compact(r.high)) + K('Indicative trade-in', TB.fmt(r.trade)) +
        K('Age', r.age + ' yrs') + K('Retained vs new', (r.estimate / p.newPrice * 100).toFixed(0) + '%') + K('Mileage vs expected', (r.deltaKm >= 0 ? '+' : '') + TB.group(r.deltaKm / 1000, 0) + 'k km');
      document.getElementById('verdict').innerHTML = '<span class="pill warn">Estimate only</span> <span class="small muted">' + c.make + ' ' + c.model + ' · ' + c.seg + '. Not a market price or dealer offer.' + (r.floorApplied ? ' Residual floor (8% of new) applied.' : '') + '</span>';
      var rows = [['Reference new price', TB.fmt(p.newPrice), ''], ['Age depreciation (' + r.age + ' yrs)', TB.fmt(r.afterAge), '× ' + r.depFactor.toFixed(3)], ['Mileage adjustment (expected ' + TB.group(r.expectedKm) + ' km)', TB.fmt(r.afterMileage), (r.mileageAdj >= 0 ? '+' : '') + (r.mileageAdj * 100).toFixed(1) + '%'], ['Condition: ' + p.condition, TB.fmt(r.afterCond), '× ' + r.condMult.toFixed(2)], ['Local market adjustment', TB.fmt(r.afterMkt), (p.marketAdj >= 0 ? '+' : '') + p.marketAdj + '%'], ['Estimated value', TB.fmt(r.estimate), r.floorApplied ? 'floor' : '']];
      document.getElementById('walk').innerHTML = '<thead><tr><th>Step</th><th>Value</th><th>Factor</th></tr></thead><tbody>' + rows.map(function (x, i) { return '<tr' + (i === rows.length - 1 ? ' style="font-weight:800"' : '') + '><td>' + x[0] + '</td><td>' + x[1] + '</td><td>' + x[2] + '</td></tr>'; }).join('') + '</tbody>';
      var pts = []; for (var a = 0; a <= 12; a++) { var rr = TBCalc.car({ newPrice: p.newPrice, year: Y0 - a, year0: Y0, mileage: (p.kmPerYear || 15000) * Math.max(a, 0.5), condition: 'Good', marketAdj: 0, d1: p.d1 / 100, d: p.d / 100, kmPerYear: p.kmPerYear }); pts.push([a, rr.estimate]); }
      C.line(document.getElementById('chart'), { series: [{ name: 'Typical value', color: '#D6AA4B', area: true, pts: pts }, { name: 'This car', color: '#F3ECDB', pts: [[r.age, r.estimate]] }], xFmt: function (x) { return x + ' yrs'; }, yFmt: function (v) { return TB.compact(v); }, tipFmt: function (v) { return TB.fmt(v); }, vline: { x: Math.min(r.age, 12), label: 'This car' }, label: 'Typical value by age' });
    }
  });
  sel.addEventListener('change', function () { setModel(); calc.run(); });
  document.addEventListener('tb:currency', function () { /* newPrice converted by shell; keep proportions */ });
});
