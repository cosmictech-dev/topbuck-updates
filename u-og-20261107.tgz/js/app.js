/* TopBuck shared shell: header/footer, ticker, currency switcher, formatting helpers. Live JSON via js/live.js (no API keys in browser). */
(function () {
  var D = window.TB_DATA, TB = window.TB = {};
  var KEY = 'tb_ccy';
  TB.ccy = (function () { try { return localStorage.getItem(KEY) || 'BWP'; } catch (e) { return 'BWP'; } })();
  if (!D.ccy[TB.ccy]) TB.ccy = 'BWP';
  var q = new URLSearchParams(location.search); if (q.get('ccy') && D.ccy[q.get('ccy')]) TB.ccy = q.get('ccy');

  TB.country = function (ccy) { return D.country[D.ccy[ccy || TB.ccy].country]; };
  TB.group = function (n, dec) { var s = Math.abs(n).toFixed(dec || 0), p = s.split('.'); p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); return (n < 0 ? '-' : '') + p.join('.'); };
  TB.fmt = function (n, o) { o = o || {}; var c = D.ccy[o.ccy || TB.ccy]; if (!isFinite(n)) return '—'; return c.sym + TB.group(n, o.dec == null ? 0 : o.dec); };
  TB.compact = function (n, ccy) { var c = D.ccy[ccy || TB.ccy], a = Math.abs(n), s = a >= 1e9 ? (a / 1e9).toFixed(1) + 'bn' : a >= 1e6 ? (a / 1e6).toFixed(a >= 1e7 ? 0 : 1) + 'm' : a >= 1e3 ? Math.round(a / 1e3) + 'k' : Math.round(a); return (n < 0 ? '-' : '') + c.sym + s; };
  TB.pct = function (n, d) { return (n >= 0 ? '' : '') + n.toFixed(d == null ? 1 : d) + '%'; };
  TB.chg = function (n) { return '<span class="' + (n >= 0 ? 'up' : 'down') + '">' + (n >= 0 ? '▲ +' : '▼ ') + n.toFixed(2) + '%</span>'; };
  TB.val = function (id) { var e = document.getElementById(id); return e ? parseFloat(String(e.value).replace(/[, ]/g, '')) : NaN; };
  TB.nice = function (v) { var a = Math.abs(v); var s = a >= 1e5 ? 1000 : a >= 1e4 ? 100 : a >= 1e3 ? 10 : 1; return Math.round(v / s) * s; };
  TB.toast = function (msg) { var t = document.querySelector('.toast'); if (!t) { t = document.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); } t.textContent = msg; t.classList.add('show'); clearTimeout(TB._tt); TB._tt = setTimeout(function () { t.classList.remove('show'); }, 2400); };
  TB.convert = function (v, from, to) { return v * D.ccy[from].toZAR / D.ccy[to].toZAR; };
  TB.saved = function () { try { return JSON.parse(localStorage.getItem('tb_saved') || '[]'); } catch (e) { return []; } };
  TB.saveScenario = function (type, label, ccy, params) {
    var list = TB.saved(); var id = 'u' + Date.now().toString(36);
    list.unshift({ id: id, client: 'c-unassigned', type: type, label: label, date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }), ccy: ccy, params: params, local: true });
    try { localStorage.setItem('tb_saved', JSON.stringify(list.slice(0, 30))); } catch (e) { }
    TB.toast('Scenario saved on this device only (example)'); return id;
  };

  /* money fields & presets */
  TB.initFields = function () {
    document.querySelectorAll('[data-money]').forEach(function (el) { // values in markup are authored in ZAR
      if (el.dataset.ready) return; el.dataset.ready = 1; el.dataset.ccy = 'ZAR';
      if (TB.ccy !== 'ZAR') el.value = TB.nice(TB.convert(parseFloat(el.value), 'ZAR', TB.ccy)); el.dataset.ccy = TB.ccy;
    });
    TB.applyPresets(); TB.syms();
  };
  TB.applyPresets = function () {
    var c = TB.country();
    document.querySelectorAll('[data-preset]').forEach(function (el) { var v = c[el.dataset.preset]; if (v != null) el.value = v; });
    document.querySelectorAll('[data-country-text]').forEach(function (el) { el.textContent = c[el.dataset.countryText]; });
  };
  TB.syms = function () { document.querySelectorAll('[data-sym]').forEach(function (e) { e.textContent = D.ccy[TB.ccy].sym; }); };
  var FLAG_SVG = {
    BWP: '<svg class="country-sel__flag" viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="9" fill="#75AADB"/><rect y="6.5" width="18" height="5" fill="#fff"/><rect y="7.5" width="18" height="3" fill="#000"/><path d="M0 0h6.5v18H0z" fill="#00A651"/></svg>',
    ZAR: '<svg class="country-sel__flag" viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="9" fill="#002395"/><path d="M0 3.2 L9 9 L0 14.8Z" fill="#DE3831"/><path d="M0 5 L7.2 9 L0 13Z" fill="#007A4D"/><path d="M0 6.2 L5.6 9 L0 11.8Z" fill="#FFB612"/><path d="M0 7.1 L4.2 9 L0 10.9Z" fill="#000"/><rect x="7.2" y="7.6" width="10.8" height="2.8" fill="#fff"/><rect x="7.2" y="8.15" width="10.8" height="1.7" fill="#FFB612"/></svg>',
    NAD: '<svg class="country-sel__flag" viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="9" fill="#003580"/><path d="M0 14.5 L14.5 0 H18 V3.5 L3.5 18 H0Z" fill="#D21034"/><path d="M0 12.2 L12.2 0 H14.8 L0 14.8Z" fill="#fff"/><path d="M0 15.8 L15.8 0 H18 V2 L2 18 H0Z" fill="#fff"/><circle cx="4.2" cy="4.2" r="1.5" fill="#FFCE00"/></svg>'
  };
  var CCY_META = {
    BWP: { name: 'Botswana', ccyLabel: 'BWP · Pula' },
    ZAR: { name: 'South Africa', ccyLabel: 'ZAR · Rand' },
    NAD: { name: 'Namibia', ccyLabel: 'NAD · Namibia dollar' }
  };
  var CHEV_SVG = '<svg class="country-sel__chev" viewBox="0 0 10 10" aria-hidden="true"><path d="M1.5 3.5 L5 7 L8.5 3.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function syncCountrySel(code) {
    var root = document.querySelector('.country-sel'); if (!root) return;
    var meta = CCY_META[code] || CCY_META.BWP;
    root.setAttribute('data-ccy', code);
    var btn = root.querySelector('.country-sel__btn');
    if (btn) {
      var nameEl = btn.querySelector('.country-sel__name');
      var ccyEl = btn.querySelector('.country-sel__ccy');
      var flagEl = btn.querySelector('.country-sel__flag');
      if (nameEl) nameEl.textContent = meta.name;
      if (ccyEl) ccyEl.textContent = meta.ccyLabel;
      if (flagEl) flagEl.outerHTML = FLAG_SVG[code] || FLAG_SVG.BWP;
    }
    root.querySelectorAll('.country-sel__opt').forEach(function (o) {
      o.setAttribute('aria-selected', o.dataset.c === code ? 'true' : 'false');
    });
  }
  function closeCountrySel() {
    var root = document.querySelector('.country-sel'); if (!root) return;
    var btn = root.querySelector('.country-sel__btn');
    var menu = root.querySelector('.country-sel__menu');
    if (btn) btn.setAttribute('aria-expanded', 'false');
    if (menu) menu.hidden = true;
  }
  TB.setCcy = function (code) {
    var from = TB.ccy; if (code === from) { syncCountrySel(code); return; } TB.ccy = code; try { localStorage.setItem(KEY, code); } catch (e) { }
    document.querySelectorAll('[data-money]').forEach(function (el) { var v = parseFloat(String(el.value).replace(/,/g, '')); if (isFinite(v)) el.value = TB.nice(TB.convert(v, from, code)); el.dataset.ccy = code; });
    TB.applyPresets(); TB.syms();
    syncCountrySel(code);
    document.dispatchEvent(new CustomEvent('tb:currency', { detail: { from: from, to: code } }));
  };
  TB.onInput = function (root, fn) { (root || document).addEventListener('input', fn); document.addEventListener('tb:currency', fn); };

  /* shell */
  var _u = 0;
  var ICON = {defs: "<linearGradient id=\"g__U__\" gradientUnits=\"userSpaceOnUse\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"58\"><stop offset=\"0\" stop-color=\"#EBCB7E\"/><stop offset=\".5\" stop-color=\"#D6AA4B\"/><stop offset=\"1\" stop-color=\"#B88B33\"/></linearGradient><mask id=\"m__U__\" maskUnits=\"userSpaceOnUse\" x=\"-2\" y=\"-2\" width=\"68\" height=\"24\"><rect x=\"-2\" y=\"-2\" width=\"68\" height=\"24\" fill=\"#fff\"/><ellipse cx=\"32\" cy=\"9.6\" rx=\"3.846\" ry=\"5.0\" fill=\"#000\"/><ellipse cx=\"32\" cy=\"9.6\" rx=\"2.308\" ry=\"3.0\" fill=\"#fff\"/></mask>", shapes: "<polygon points=\"32,1.6 2.2,15.6 61.8,15.6\" fill=\"url(#g__U__)\" stroke=\"url(#g__U__)\" stroke-width=\"2.8\" stroke-linejoin=\"round\" mask=\"url(#m__U__)\"/><rect x=\"0\" y=\"18.6\" width=\"64\" height=\"1.9\" rx=\"0.95\" fill=\"url(#g__U__)\"/><g fill=\"url(#g__U__)\"><rect x=\"4\" y=\"20.6\" width=\"8\" height=\"4.0\"/><rect x=\"5.5\" y=\"24.59\" width=\"5.0\" height=\"19.419999999999998\"/><rect x=\"4\" y=\"44.0\" width=\"8\" height=\"4.0\"/><rect x=\"16\" y=\"20.6\" width=\"8\" height=\"4.0\"/><rect x=\"17.5\" y=\"24.59\" width=\"5.0\" height=\"19.419999999999998\"/><rect x=\"16\" y=\"44.0\" width=\"8\" height=\"4.0\"/><rect x=\"40\" y=\"20.6\" width=\"8\" height=\"4.0\"/><rect x=\"41.5\" y=\"24.59\" width=\"5.0\" height=\"19.419999999999998\"/><rect x=\"40\" y=\"44.0\" width=\"8\" height=\"4.0\"/><rect x=\"52\" y=\"20.6\" width=\"8\" height=\"4.0\"/><rect x=\"53.5\" y=\"24.59\" width=\"5.0\" height=\"19.419999999999998\"/><rect x=\"52\" y=\"44.0\" width=\"8\" height=\"4.0\"/></g><rect x=\"0\" y=\"48.0\" width=\"64\" height=\"2.0\" rx=\"1.0\" fill=\"url(#g__U__)\"/><rect x=\"0\" y=\"52.0\" width=\"64\" height=\"2.0\" rx=\"1.0\" fill=\"url(#g__U__)\"/><rect x=\"0\" y=\"56.0\" width=\"64\" height=\"2.0\" rx=\"1.0\" fill=\"url(#g__U__)\"/>"};
  function iconSVG() { var u = 'b' + (++_u), r = function (s) { return s.replace(/__U__/g, u); }; return '<svg viewBox="0 0 83.2 58.0" aria-hidden="true" focusable="false"><defs>' + r(ICON.defs) + '</defs><g transform="scale(1.3 1)">' + r(ICON.shapes) + '</g></svg>'; }
  TB.brandHTML = function () { return '<a class="brand" href="index.html" aria-label="TopBuck home">' + iconSVG() + '<span class="stack"><span class="wm">TOP<b>BUCK</b></span><span class="tagline">Insights · Tools · News</span></span></a>'; };
  var nav = [['Insights', 'news.html?type=insight', 'insights'], ['News', 'news.html?type=news', 'news'], ['Markets', 'markets.html', 'markets'], ['Tools', 'tools.html', 'tools'], ['Learn', 'learn.html', 'learn']];
  function header() {
    var page = document.body.dataset.nav || '';
    var links = nav.map(function (n) { return '<a href="' + n[1] + '"' + (page === n[2] ? ' class="active" aria-current="page"' : '') + '>' + n[0] + '</a>'; }).join('');
    var cur = TB.ccy in CCY_META ? TB.ccy : 'BWP';
    var meta = CCY_META[cur];
    var opts = ['BWP', 'ZAR', 'NAD'].map(function (c) {
      return '<li role="none"><button type="button" class="country-sel__opt" role="option" data-c="' + c + '" aria-selected="' + (c === cur) + '">' +
        FLAG_SVG[c] + CCY_META[c].name + '<span class="country-sel__opt-meta">' + c + '</span></button></li>';
    }).join('');
    var ccy = '<div class="country-sel" data-ccy="' + cur + '">' +
      '<button type="button" class="country-sel__btn" aria-haspopup="listbox" aria-expanded="false" aria-controls="tb-country-menu" id="tb-country-btn" aria-label="Country and currency">' +
      FLAG_SVG[cur] +
      '<span class="country-sel__label"><span class="country-sel__name">' + meta.name + '</span><span class="country-sel__ccy">' + meta.ccyLabel + '</span></span>' +
      CHEV_SVG +
      '</button>' +
      '<ul class="country-sel__menu" id="tb-country-menu" role="listbox" aria-labelledby="tb-country-btn" hidden>' + opts + '</ul></div>';
    return '<div class="demo-bar"><b>TOPBUCK</b> — markets and news load from server feeds when available. Informational only — not financial advice.</div>' +
      '<header class="site-header"><div class="wrap nav">' + TB.brandHTML() + '<nav class="nav-links" aria-label="Primary">' + links + '</nav><span class="nav-spacer"></span>' + ccy +
      '<a class="btn btn-gold btn-sm signin-link" href="signin.html">Sign in</a><button class="menu-btn" type="button" aria-label="Menu" aria-expanded="false" aria-controls="mm"><span></span></button></div>' +
      '<div class="mobile-menu" id="mm">' + links + '<a href="pricing.html">Pricing</a><a href="signin.html">Sign in</a></div></header>';
  }
  function ticker() {
    var items = [].concat(D.indices, D.fx.slice(0, 4), D.commodities.slice(0, 3));
    var one = items.map(function (i) { var d = i.last >= 1000 ? 1 : 2; return '<span class="tick"><span class="n">' + i.name + '</span><span class="v">' + TB.group(i.last, d) + '</span>' + TB.chg(i.chg) + '</span>'; }).join('');
    return '<div class="ticker" role="region" aria-label="Market ticker (delayed / indicative)"><div class="ticker-track" aria-hidden="false">' + one + one + '</div></div>';
  }
  function footer() {
    return '<footer class="site-footer"><div class="wrap"><div class="foot-grid"><div>' + TB.brandHTML() + '<p class="small muted" style="margin-top:14px;max-width:38ch">Financial insights, news and tools for people in Botswana, South Africa and Namibia.</p><p class="small" style="margin:10px 0 0"><b style="color:var(--gold-400)">topbuck.app</b></p></div>' +
      '<div><h4>Product</h4><a href="tools.html">Tools</a><a href="markets.html">Markets</a><a href="news.html">News &amp; insights</a><a href="learn.html">Learn</a><a href="pricing.html">Pricing</a></div>' +
      '<div><h4>Account</h4><a href="client.html">Client portal</a><a href="signin.html">Sign in</a></div>' +
      '<div><h4>Company</h4><a href="about.html">About</a><a href="about.html#compliance">Disclaimers</a><a href="privacy.html">Privacy</a></div></div>' +
      '<p class="disclaimer"><b>Disclaimer.</b> TopBuck provides financial literature for general information, awareness and education only. Information contained in TopBuck publications does not constitute financial advice. Speak to a professional financial advisor when in need of financial advice.</p>' +
      '<p class="disclaimer"><b>Information only.</b> Market prices are delayed / indicative (not live, not for trading execution). FX figures are indicative third-party rates — not Bank of Botswana official rates. News items are headlines with links to the original publisher. Calculators are illustrative planning tools. TopBuck is operated by Cosmic Technologies. We are not licensed or authorised by NBFIRA, the FSCA (FAIS Act) or NAMFISA (FIMA) to give financial advice or intermediary services. Nothing on this site is personal advice. Before you act, speak with an authorised or licensed provider in your country. © 2026 TopBuck (topbuck.app) · Cosmic Technologies.</p></div></footer>';
  }
  function boot() {
    var h = document.getElementById('tb-header'); if (h) { h.innerHTML = header() + (document.body.dataset.ticker ? ticker() : ''); }
    var f = document.getElementById('tb-footer'); if (f) f.innerHTML = footer();
    (function wireCountrySel() {
      var root = document.querySelector('.country-sel'); if (!root) return;
      var btn = root.querySelector('.country-sel__btn');
      var menu = root.querySelector('.country-sel__menu');
      if (!btn || !menu) return;
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = btn.getAttribute('aria-expanded') === 'true';
        if (open) { closeCountrySel(); }
        else { btn.setAttribute('aria-expanded', 'true'); menu.hidden = false; }
      });
      menu.querySelectorAll('.country-sel__opt').forEach(function (o) {
        o.addEventListener('click', function (e) {
          e.stopPropagation();
          TB.setCcy(o.dataset.c);
          closeCountrySel();
        });
      });
      document.addEventListener('click', function (e) {
        if (!root.contains(e.target)) closeCountrySel();
      });
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeCountrySel();
      });
    })();
    var mb = document.querySelector('.menu-btn'); if (mb) mb.addEventListener('click', function () { var o = document.getElementById('mm').classList.toggle('open'); mb.setAttribute('aria-expanded', o); });
    TB.initFields();
    document.dispatchEvent(new CustomEvent('tb:ready'));
  }
  function startBoot() {
    if (window.__tb_booted) return;
    window.__tb_booted = true;
    boot();
    // Re-stamp demo bar after header exists if live.js already ran
    if (window.TB_FEEDS && document.querySelector('.demo-bar')) {
      document.dispatchEvent(new CustomEvent('tb:feeds', { detail: (window.TB_DATA && window.TB_DATA.live) || {} }));
    }
  }
  function schedule() {
    if (window.TB_FEEDS_READY) {
      var t = setTimeout(startBoot, 2800);
      window.TB_FEEDS_READY.then(function () { clearTimeout(t); startBoot(); });
    } else {
      startBoot();
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', schedule); else schedule();
})();
