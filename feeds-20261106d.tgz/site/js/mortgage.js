document.addEventListener('tb:ready', function () {
  var C = TBChart, K = TB.kpi, view = 'y', last;
  function toCSV(res) { var s = 'Month,Payment,Interest,Capital,Balance\n'; res.rows.forEach(function (r) { s += [r.m, r.payment.toFixed(2), r.interest.toFixed(2), r.principal.toFixed(2), r.balance.toFixed(2)].join(',') + '\n'; }); return s; }
  function sched() {
    var t = document.getElementById('sched'); if (!last) return;
    if (view === 'y') t.innerHTML = '<thead><tr><th>Year</th><th>Interest</th><th>Capital</th><th>Closing balance</th></tr></thead><tbody>' + last.yearly.map(function (y) { return '<tr><td>' + y.year + '</td><td>' + TB.fmt(y.interest) + '</td><td>' + TB.fmt(y.principal) + '</td><td>' + TB.fmt(y.balance) + '</td></tr>'; }).join('') + '</tbody>';
    else t.innerHTML = '<thead><tr><th>Month</th><th>Payment</th><th>Interest</th><th>Capital</th><th>Balance</th></tr></thead><tbody>' + last.rows.map(function (r) { return '<tr><td>' + r.m + '</td><td>' + TB.fmt(r.payment, { dec: 2 }) + '</td><td>' + TB.fmt(r.interest, { dec: 2 }) + '</td><td>' + TB.fmt(r.principal, { dec: 2 }) + '</td><td>' + TB.fmt(r.balance, { dec: 2 }) + '</td></tr>'; }).join('') + '</tbody>';
  }
  TB.calc({
    type: 'mortgage', fields: { price: 'price', depositPct: 'dep', years: 'years', rate: 'rate', extra: 'extra', income: 'income' },
    label: function (p) { return TB.compact(p.price) + ' home, ' + p.depositPct + '% deposit, ' + p.years + ' yrs'; },
    valid: function (p) { if (!(p.price > 0)) return 'Enter a property price.'; if (!(p.years >= 1)) return 'Term must be at least 1 year.'; if (p.depositPct >= 100) return 'Deposit must be below 100%.'; return true; },
    run: function (p) {
      var r = TBCalc.mortgage(p); last = r;
      document.getElementById('kpis').innerHTML = K('Loan amount', TB.fmt(r.loan)) + K('Monthly instalment', TB.fmt(r.payment + (p.extra || 0)), true) + K('Total interest', TB.fmt(r.totalInterest)) +
        K('Total repaid', TB.fmt(r.totalPaid)) + K('Term to repay', Math.floor(r.months / 12) + ' yrs ' + (r.months % 12) + ' m') + K('Income for 30% rule of thumb (example)', TB.fmt(r.requiredIncome));
      var v = '<span class="small muted">Deposit ' + TB.fmt(r.deposit) + '. Interest is ' + (r.totalInterest / r.loan * 100).toFixed(0) + '% of the amount borrowed.</span>';
      if (p.extra > 0) v = '<span class="pill ok">Extra payments save ' + TB.fmt(r.interestSaved) + ' in interest</span> <span class="small muted">and ' + Math.floor(r.monthsSaved / 12) + ' yrs ' + (r.monthsSaved % 12) + ' m off the term.</span>';
      if (p.income > 0) { var ratio = (r.payment + (p.extra || 0)) / p.income; v += ' <span class="pill ' + (ratio <= 0.3 ? 'ok' : 'warn') + '">Repayment = ' + (ratio * 100).toFixed(0) + '% of income</span> <span class="small muted">Rule of thumb only — your lender decides.</span>'; }
      document.getElementById('verdict').innerHTML = v;
      C.columns(document.getElementById('chart'), { cats: r.yearly.map(function (y) { return y.year; }), stacks: [{ name: 'Capital', color: '#D6AA4B', vals: r.yearly.map(function (y) { return y.principal; }) }, { name: 'Interest', color: '#7FA0D6', vals: r.yearly.map(function (y) { return y.interest; }) }], yFmt: function (v) { return TB.compact(v); }, tipFmt: function (v) { return TB.fmt(v); }, xFmt: function (c) { return 'Yr ' + c; }, label: 'Interest versus capital per year' });
      C.line(document.getElementById('chart2'), { series: [{ name: 'Outstanding balance', color: '#EBCB7E', area: true, pts: [[0, r.loan]].concat(r.yearly.map(function (y) { return [y.year, y.balance]; })) }], xFmt: function (x) { return 'Yr ' + x; }, yFmt: function (v) { return TB.compact(v); }, tipFmt: function (v) { return TB.fmt(v); }, label: 'Outstanding balance' });
      sched();
    }
  });
  document.getElementById('sview').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; view = b.dataset.v; this.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); sched(); });
  document.getElementById('csv').addEventListener('click', function () { if (!last) return; var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([toCSV(last)], { type: 'text/csv' })); a.download = 'topbuck-amortisation-example.csv'; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 500); });
});
