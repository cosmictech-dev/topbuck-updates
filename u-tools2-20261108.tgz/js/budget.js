/* My Monthly Budget — money in, money out and what is left each month. Figures stay in this browser (localStorage). */
document.addEventListener('tb:ready', function () {
  var KEY = 'tb_bud_v1', SNAP = 'tb_bud_snaps';
  var CATS = [['housing', 'Housing (rent or bond)'], ['food', 'Food and groceries'], ['transport', 'Transport'], ['utilities', 'Electricity, water and airtime'], ['school', 'School and childcare'], ['cover', 'Insurance and medical'], ['debt', 'Debt repayments'], ['savings', 'Savings and investments'], ['family', 'Family support'], ['personal', 'Personal and entertainment'], ['other', 'Other']];
  var LBL = {}; CATS.forEach(function (c) { LBL[c[0]] = c[1]; });
  var EX = { ccy: 'ZAR',
    inc: [{ n: 'Salary after tax', v: 32000 }, { n: 'Side income', v: 3000 }],
    exp: [{ n: 'Rent or bond', c: 'housing', v: 9500 }, { n: 'Groceries', c: 'food', v: 5200 }, { n: 'Fuel and taxi', c: 'transport', v: 3200 }, { n: 'Electricity, water and data', c: 'utilities', v: 1800 }, { n: 'School fees', c: 'school', v: 2500 }, { n: 'Medical aid and insurance', c: 'cover', v: 2400 }, { n: 'Car and store repayments', c: 'debt', v: 4300 }, { n: 'Savings', c: 'savings', v: 2000 }, { n: 'Support to family', c: 'family', v: 1500 }, { n: 'Eating out and outings', c: 'personal', v: 1200 }] };
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { var x = parseFloat(String(v).replace(/[, ]/g, '')); return isFinite(x) ? x : 0; }
  function conv(v, from) { return from && from !== TB.ccy && v !== '' ? TB.nice(TB.convert(v, from, TB.ccy)) : v; }
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
  function snaps() { try { return JSON.parse(localStorage.getItem(SNAP) || '[]'); } catch (e) { return []; } }
  function amt(v) { return '<div class="inp-group has-pre"><span class="pre" data-sym>' + TB_DATA.ccy[TB.ccy].sym + '</span><input class="inp" type="number" inputmode="decimal" step="any" min="0" aria-label="Amount per month" data-f="v" data-money data-ready="1" data-ccy="' + TB.ccy + '" value="' + esc(v) + '"></div>'; }
  var X = '<button class="bs-x" type="button" aria-label="Remove">✕</button>';
  function incRow(r) { return '<div class="bs-row" data-k="i"><input class="inp" aria-label="Income source" placeholder="e.g. Salary after tax" value="' + esc(r.n) + '" data-f="n">' + amt(r.v) + X + '</div>'; }
  function expRow(r) {
    var o = CATS.map(function (c) { return '<option value="' + c[0] + '"' + (r.c === c[0] ? ' selected' : '') + '>' + c[1] + '</option>'; }).join('');
    return '<div class="bs-row" data-k="e"><div><input class="inp" aria-label="Spending item" placeholder="e.g. Groceries" value="' + esc(r.n) + '" data-f="n"><select class="inp bs-sub" aria-label="Category" data-f="c">' + o + '</select></div>' + amt(r.v) + X + '</div>';
  }
  function fill(d) {
    $('inc').innerHTML = d.inc.map(function (r) { return incRow({ n: r.n, v: conv(r.v, d.ccy) }); }).join('');
    $('exp').innerHTML = d.exp.map(function (r) { return expRow({ n: r.n, c: r.c, v: conv(r.v, d.ccy) }); }).join('');
  }
  function read() {
    var d = { ccy: TB.ccy, inc: [], exp: [] };
    document.querySelectorAll('.bs-row').forEach(function (r) {
      var g = function (f) { var e = r.querySelector('[data-f="' + f + '"]'); return e ? e.value : ''; };
      if (r.dataset.k === 'i') d.inc.push({ n: g('n'), v: num(g('v')) }); else d.exp.push({ n: g('n'), c: g('c'), v: num(g('v')) });
    });
    return d;
  }
  function tip(level, title, body) { return '<div class="bs-tip"><span class="bs-dot ' + level + '"></span><div><h4>' + title + '</h4><p>' + body + '</p></div></div>'; }
  function pct(x) { return Math.round(x * 100) + '%'; }

  function run() {
    var d = read(), I = 0, E = 0, by = {};
    CATS.forEach(function (c) { by[c[0]] = 0; });
    d.inc.forEach(function (r) { I += r.v; });
    d.exp.forEach(function (r) { E += r.v; by[r.c] = (by[r.c] || 0) + r.v; });
    var Lf = I - E;
    $('totI').textContent = TB.fmt(I); $('totE').textContent = TB.fmt(E);
    $('leftL').textContent = Lf >= 0 ? 'Left over this month' : 'Short this month';
    $('left').textContent = TB.fmt(Math.abs(Lf)); $('left').className = 'v ' + (Lf >= 0 ? '' : 'down');
    $('lefteq').textContent = TB.fmt(I) + ' in − ' + TB.fmt(E) + ' out';
    var s = snaps(), last = s[s.length - 1];
    if (last) { var prev = TB.convert(last.i - last.e, last.ccy, TB.ccy), ch = Lf - prev;
      $('since').innerHTML = '<span class="' + (ch >= 0 ? 'up' : 'down') + '">' + (ch >= 0 ? '▲ ' : '▼ ') + TB.fmt(Math.abs(ch)) + '</span> <span class="muted">compared with your snapshot on ' + esc(last.d) + '</span>';
    } else $('since').innerHTML = '<span class="muted">Save a monthly snapshot to track how your budget changes.</span>';

    var t = '';
    if (I <= 0) t = tip('', 'Start with what comes in', 'Add your income after tax, then list what goes out each month, including savings and debt repayments.');
    else {
      t += Lf > 0 ? tip('good', 'Left over: ' + TB.fmt(Lf) + ' (' + pct(Lf / I) + ' of income)', 'Money left without a purpose often gets spent without noticing. Deciding where it goes, for example savings, a buffer or a debt, is part of budgeting.')
        : Lf === 0 ? tip('watch', 'Every amount has a job', 'Your income and spending match exactly, which leaves no room for a surprise cost this month.')
        : tip('act', 'Short by ' + TB.fmt(-Lf), 'You plan to spend more than comes in. A shortfall like this is usually covered from savings or with new debt, which shows up on your balance sheet.');
      var sr = by.savings / I;
      t += sr >= .15 ? tip('good', 'Saving rate: ' + pct(sr), 'You put ' + pct(sr) + ' of income into savings and investments. These amounts add to the assets on your balance sheet.')
        : sr > 0 ? tip('watch', 'Saving rate: ' + pct(sr), 'You put ' + pct(sr) + ' of income into savings and investments. Many people aim for 10% to 20%, depending on their situation.')
        : tip('watch', 'No savings line', 'Nothing is set aside for savings yet. Even a small regular amount builds a buffer over time.');
      var dr = by.debt / I;
      if (by.debt > 0) t += dr > .4 ? tip('act', 'Debt repayments: ' + pct(dr) + ' of income', 'Repayments take a large share of your income, which leaves less room if rates or costs rise. Repayments reduce what you owe on your balance sheet.')
        : dr > .2 ? tip('watch', 'Debt repayments: ' + pct(dr) + ' of income', 'A noticeable share of income goes to debt. As each debt is paid off, that amount is freed up.')
        : tip('good', 'Debt repayments: ' + pct(dr) + ' of income', 'Debt repayments take a modest share of your income.');
      var hr = by.housing / I;
      if (by.housing > 0) t += hr > .35 ? tip('watch', 'Housing: ' + pct(hr) + ' of income', 'Housing takes more than a third of your income. Housing costs are often the hardest to change quickly, so they shape the rest of the budget.')
        : tip('good', 'Housing: ' + pct(hr) + ' of income', 'Housing takes a third of your income or less.');
      var top = CATS.filter(function (c) { return c[0] !== 'savings'; }).map(function (c) { return [c[1], by[c[0]]]; }).sort(function (a, b) { return b[1] - a[1]; })[0];
      if (top && top[1] > 0) t += tip('', 'Biggest spending area: ' + esc(top[0]), 'It costs ' + TB.fmt(top[1]) + ' a month, or ' + pct(top[1] / I) + ' of income. Try changing it above to see the effect on what is left.');
    }
    $('tips').innerHTML = t;

    $('hist').innerHTML = s.length ? '<table class="tbl" style="width:100%"><thead><tr><th style="text-align:left">Month</th><th>Income</th><th>Spending</th><th>Left</th></tr></thead><tbody>' +
      s.slice(-12).map(function (x) { var i = TB.convert(x.i, x.ccy, TB.ccy), e = TB.convert(x.e, x.ccy, TB.ccy);
        return '<tr><td style="text-align:left">' + esc(x.d) + '</td><td>' + TB.fmt(i) + '</td><td>' + TB.fmt(e) + '</td><td class="' + (i - e >= 0 ? 'up' : 'down') + '">' + (i - e < 0 ? '−' : '') + TB.fmt(Math.abs(i - e)) + '</td></tr>'; }).reverse().join('') + '</tbody></table>'
      : '<p class="small muted" style="margin:0">No snapshots yet.</p>';
    try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) { }
    return { I: I, E: E };
  }

  var saved = load(); fill(saved && saved.inc ? saved : EX);
  var main = $('main');
  main.addEventListener('input', function (e) { if (e.target.closest('.bs-row')) run(); });
  main.addEventListener('change', function (e) { if (e.target.closest('.bs-row')) run(); });
  main.addEventListener('click', function (e) { var x = e.target.closest('.bs-x'); if (x) { x.closest('.bs-row').remove(); run(); } });
  $('addInc').addEventListener('click', function () { $('inc').insertAdjacentHTML('beforeend', incRow({ n: '', v: '' })); $('inc').lastElementChild.querySelector('input').focus(); });
  $('addExp').addEventListener('click', function () { $('exp').insertAdjacentHTML('beforeend', expRow({ n: '', c: 'other', v: '' })); $('exp').lastElementChild.querySelector('input').focus(); });
  $('snap').addEventListener('click', function () { var r = run(), s = snaps(), dt = new Date().toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
    if (s.length && s[s.length - 1].d === dt) s.pop(); s.push({ d: dt, i: r.I, e: r.E, ccy: TB.ccy }); try { localStorage.setItem(SNAP, JSON.stringify(s.slice(-60))); } catch (e) { } run(); TB.toast('Snapshot saved on this device only'); });
  $('reset').addEventListener('click', function () { if (!confirm('Clear your figures and snapshots from this device?')) return; try { localStorage.removeItem(KEY); localStorage.removeItem(SNAP); } catch (e) { }
    $('inc').innerHTML = incRow({ n: '', v: '' }); $('exp').innerHTML = expRow({ n: '', c: 'other', v: '' }); run(); });
  document.addEventListener('tb:currency', run);
  run();
});
