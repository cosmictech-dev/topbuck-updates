document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart, q = new URLSearchParams(location.search);
  var type = q.get('type') || 'all', cat = 'All', text = '';
  var tabs = [['all', 'All'], ['news', 'News'], ['insight', 'Insights']];
  function drawTabs() { document.getElementById('ntabs').innerHTML = tabs.map(function (t) { return '<button type="button" data-t="' + t[0] + '" aria-pressed="' + (t[0] === type) + '">' + t[1] + '</button>'; }).join(''); }
  function drawCats() { var cats = ['All'].concat(Array.from(new Set(D.news.map(function (n) { return n.cat; })))); document.getElementById('ncats').innerHTML = cats.map(function (c) { return '<button type="button" class="chip' + (c === cat ? ' on' : '') + '" data-c="' + c + '">' + c + '</button>'; }).join(''); }
  function list() {
    var items = D.news.filter(function (n) { return (type === 'all' || n.type === type) && (cat === 'All' || n.cat === cat) && (!text || (n.title + n.dek + n.cat).toLowerCase().indexOf(text) >= 0); });
    document.getElementById('nlist').innerHTML = items.length ? items.map(function (n) { return '<article class="card hover news-card"><a class="news-thumb" href="article.html?id=' + n.id + '" aria-label="' + C.esc(n.title) + '">' + C.thumb(n.id.length * 7 + parseInt(n.id.slice(1)) * 13, n.cat) + '</a><div class="meta"><span class="tag">' + n.cat + '</span><span class="tag ex">' + (n.type === 'insight' ? 'Insight' : 'News') + ' · example</span><span>' + n.mins + ' min</span></div><h3><a href="article.html?id=' + n.id + '">' + C.esc(n.title) + '</a></h3><p class="small muted" style="margin:0">' + C.esc(n.dek) + '</p><div class="meta" style="margin-top:auto">' + n.date + ' · ' + C.esc(n.author) + '</div></article>'; }).join('') : '<p class="muted">No articles match your filters.</p>';
  }
  drawTabs(); drawCats(); list();
  document.getElementById('ntabs').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; type = b.dataset.t; drawTabs(); list(); });
  document.getElementById('ncats').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; cat = b.dataset.c; drawCats(); list(); });
  document.getElementById('nq').addEventListener('input', function (e) { text = e.target.value.toLowerCase(); list(); });
});
