document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart;
  var mMeta = (window.TB_FEEDS && TB_FEEDS.meta().markets) || {};
  var nMeta = (window.TB_FEEDS && TB_FEEDS.meta().news) || {};
  var fxMeta = (window.TB_FEEDS && TB_FEEDS.meta().fx) || {};
  function liveOk(st) { return st === 'ok' || st === 'partial' || st === 'stale'; }
  function equitiesLive() {
    var panels = (D.live && D.live.markets && D.live.markets.panels) || {};
    if (panels.equities) return liveOk(panels.equities) && D.indices && D.indices.length;
    return liveOk(mMeta.status) && D.indices && D.indices.length;
  }
  function fxLive() { return liveOk(fxMeta.status || (D.live && D.live.status && D.live.status.fx)) && D.fx && D.fx.length; }
  function newsLive() {
    return liveOk(nMeta.status || (D.live && D.live.status && D.live.status.news)) && D.news.some(function (n) { return n.type === 'news' && n.external; });
  }
  function show(id, on) { var el = document.getElementById(id); if (el) el.hidden = !on; }
  function showSel(sel, on) { document.querySelectorAll(sel).forEach(function (el) { el.hidden = !on; }); }

  var eq = equitiesLive(), fx = fxLive(), nw = newsLive();
  var mEye = document.getElementById('home-mkt-eyebrow');
  if (mEye) mEye.textContent = eq ? 'Markets · Delayed / indicative' : 'Markets';
  var nEye = document.getElementById('home-news-eyebrow');
  if (nEye) nEye.textContent = nw ? 'Latest news · Headlines & links' : 'Latest news';
  show('home-mkt-credit', eq || fx);
  show('home-mkt-soon', !(eq || fx));
  show('home-news-credit', nw);
  show('home-news-soon', !nw);
  // If only FX is live, credit still OK (mentions FX); hide Mansa-heavy line details via partial — credit text covers both

  function hrefFor(n) { return (n.external && n.url) ? n.url : ('article.html?id=' + encodeURIComponent(n.id)); }
  function tgt(n) { return (n.external && n.url) ? ' target="_blank" rel="noopener noreferrer"' : ''; }
  function card(n) {
    return '<article class="card hover news-card"><a class="news-thumb" href="' + hrefFor(n) + '"' + tgt(n) + ' aria-label="' + C.esc(n.title) + '"></a><div class="meta"><span class="tag">' + C.esc(n.cat) + '</span><span class="tag">' + (n.external ? 'Headline' : 'Insight') + '</span></div><h3><a href="' + hrefFor(n) + '"' + tgt(n) + '>' + C.esc(n.title) + '</a></h3><p class="small muted" style="margin:0">' + C.esc(n.dek || '') + '</p></article>';
  }
  var ins = D.news.filter(function (n) { return n.type === 'insight'; });
  var insightsEl = document.getElementById('home-insights');
  if (insightsEl) {
    insightsEl.innerHTML = ins.length
      ? (card(ins[0]) + (ins.length > 1 ? '<div class="stack">' + ins.slice(1, 3).map(card).join('') + '</div>' : ''))
      : '<p class="muted small">Editorial insights will appear here when published.</p>';
  }
  var mk = document.getElementById('home-mkts');
  if (mk) {
    if (eq) {
      mk.innerHTML = D.indices.slice(0, 5).map(function (i) {
        var vals = D.series(i.seed, 30, 100, 0.006, 0);
        var as = i.asOf || i.updatedAt; var asTxt = ''; try { asTxt = as && window.TB_FEEDS ? TB_FEEDS.asOfText(as) : (as || ''); } catch (e) { asTxt = as || ''; }
        return '<div class="mkt-row"><div><div class="nm">' + i.name + '</div><div class="sub">' + i.mkt + ' · delayed / indicative' + (asTxt ? ' · as of ' + asTxt : '') + '</div></div>' + C.spark(vals, i.chg >= 0 ? '#58C28A' : '#E4796B') + '<div style="text-align:right"><div class="num" style="font-weight:700">' + TB.group(i.last, 1) + '</div><div class="small">' + TB.chg(i.chg) + '</div></div></div>';
      }).join('');
    } else if (fx) {
      mk.innerHTML = D.fx.slice(0, 5).map(function (i) {
        return '<div class="mkt-row"><div><div class="nm">' + i.name + '</div><div class="sub">FX · indicative</div></div><div style="text-align:right"><div class="num" style="font-weight:700">' + TB.group(i.last, 2) + '</div><div class="small">' + TB.chg(i.chg == null ? 0 : i.chg) + '</div></div></div>';
      }).join('');
    } else {
      mk.innerHTML = '<p class="muted small">Live market snapshot coming soon. <a href="markets.html">Markets</a></p>';
    }
  }
  var newsEl = document.getElementById('home-news');
  if (newsEl) {
    var news = D.news.filter(function (n) { return n.type === 'news'; }).slice(0, 5);
    newsEl.innerHTML = news.length ? news.map(function (n) {
      return '<div class="mkt-row" style="grid-template-columns:1fr"><div><div class="meta" style="margin-bottom:4px"><span class="tag">' + C.esc(n.cat) + '</span><span>' + C.esc(n.date || '') + '</span></div><a href="' + hrefFor(n) + '"' + tgt(n) + ' style="color:var(--ivory-50);font-weight:700">' + C.esc(n.title) + '</a></div></div>';
    }).join('') : '<p class="muted small">Live headlines coming soon. <a href="news.html">News</a></p>';
  }
  var tools = [
    ['retirement.html', 'Retirement calculator', 'Will your savings last?', '<path d="M12 3v18M5 9l7-6 7 6M4 21h16M7 21v-6h10v6"/>'],
    ['mortgage.html', 'Home loan calculator', 'What will the bond really cost?', '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'],
    ['education.html', 'Education fees calculator', 'Plan school and university with clear inflation paths.', '<path d="M2 9l10-5 10 5-10 5zM6 11.5V16c0 1.5 3 3 6 3s6-1.500 6-3v-4.500"/>'],
    ['car-valuator.html', 'Used car valuator', 'A transparent ballpark from age, mileage and condition.', '<path d="M3 15l2-6a2 2 0 0 1 2-1.500h10a2 2 0 0 1 2 1.500l2 6v4h-3v-2H6v2H3zM7 15h.01M17 15h.01"/>']];
  var toolsEl = document.getElementById('home-tools');
  if (toolsEl) {
    toolsEl.innerHTML = tools.map(function (t) { return '<a class="card hover tool-card" href="' + t[0] + '" style="color:inherit"><div class="tool-ico"><svg viewBox="0 0 24 24">' + t[3] + '</svg></div><h3 style="margin:0">' + t[1] + '</h3><p class="small muted" style="margin:0">' + t[2] + '</p><span class="go">Open →</span></a>'; }).join('');
  }
});
