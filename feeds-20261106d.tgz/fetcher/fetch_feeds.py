#!/usr/bin/env python3
"""TopBuck live feed fetcher.

Writes fx.json, markets.json, news.json into the static site data dir.
API keys stay in /opt/topbuck/feeds.env (never in the browser).

Legal (Tshepo memo 2026-11-06): no BSE/JSE/NSX scraping; no BoB website
commercial republication; equity prices delayed/indicative + Mansa credit;
JSE ≥15 min delay wording; Currents = headline+source+link only; never claim
official/exchange-licensed while on Mansa Free.
"""
from __future__ import annotations

import json
import re
import os
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ZONE_LABEL = "Africa/Johannesburg"
USER_AGENT = "TopBuckFeeds/1.0 (+https://topbuck.app; Cosmic Technologies)"

DEFAULTS = {
    "MANSA_BASE": "https://mansaapi.com/api/v1",
    "CURRENTS_BASE": "https://api.currentsapi.services/v1",
    "FX_URL": "https://open.er-api.com/v6/latest/USD",
    "SARB_URL": "https://custom.resbank.co.za/SarbWebApi/WebIndicators/CurrentMarketRates",
    "OUT_DIR": "/opt/topbuck/www/data",
    "STATE_DIR": "/opt/topbuck/feeds-state",
    "ENV_FILE": "/opt/topbuck/feeds.env",
}


def now_iso() -> str:
    # Aware UTC; display layer converts. Label zone in meta.
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_env(path: Path) -> Dict[str, str]:
    env = dict(os.environ)
    if path.is_file():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def http_get(url: str, headers: Optional[Dict[str, str]] = None, timeout: int = 45) -> Tuple[int, bytes]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.getcode(), resp.read()
    except urllib.error.HTTPError as e:
        body = e.read() if hasattr(e, "read") else b""
        return e.code, body
    except Exception as e:
        raise RuntimeError(f"GET {url} failed: {e}") from e


def read_json_file(path: Path) -> Optional[Dict[str, Any]]:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def atomic_write(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(obj, ensure_ascii=False, indent=2) + "\n"
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def pct_chg(new: Optional[float], old: Optional[float]) -> Optional[float]:
    if new is None or old is None or old == 0:
        return None
    return round((new - old) / old * 100.0, 2)


# ---- FX (ExchangeRate-API open, keyless) ----

def fetch_fx(env: Dict[str, str], prev: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    url = env.get("FX_URL", DEFAULTS["FX_URL"])
    code, raw = http_get(url)
    if code != 200:
        raise RuntimeError(f"FX HTTP {code}: {raw[:200]!r}")
    payload = json.loads(raw.decode("utf-8"))
    if payload.get("result") != "success":
        raise RuntimeError(f"FX API result={payload.get('result')}")
    rates = payload["rates"]
    usd_zar = float(rates["ZAR"])
    usd_bwp = float(rates["BWP"])
    usd_nad = float(rates.get("NAD") or usd_zar)  # NAD ~ ZAR peg; API may still return NAD
    usd_eur = float(rates["EUR"])
    usd_gbp = float(rates["GBP"])

    # Quote as foreign per USD style used on the prototype board
    pairs_map = {
        "usdzar": ("USD / ZAR", usd_zar),
        "usdbwp": ("USD / BWP", usd_bwp),
        "usdnad": ("USD / NAD", usd_nad),
        "eurzar": ("EUR / ZAR", usd_zar / usd_eur),
        "gbpzar": ("GBP / ZAR", usd_zar / usd_gbp),
        "bwpzar": ("BWP / ZAR", usd_zar / usd_bwp),
    }
    prev_pairs = {p["id"]: p.get("last") for p in (prev or {}).get("pairs", []) if isinstance(p, dict)}
    pairs = []
    for pid, (name, last) in pairs_map.items():
        last = round(float(last), 6 if last < 10 else 4)
        pairs.append({
            "id": pid,
            "name": name,
            "last": last,
            "chg": pct_chg(last, prev_pairs.get(pid)),
            "seed": abs(hash(pid)) % 1000,
        })

    to_zar = {
        "BWP": round(usd_zar / usd_bwp, 6),
        "ZAR": 1.0,
        "NAD": round(usd_zar / usd_nad, 6),
    }

    return {
        "asOf": now_iso(),
        "providerUpdated": payload.get("time_last_update_utc"),
        "providerNext": payload.get("time_next_update_utc"),
        "zone": ZONE_LABEL,
        "source": "ExchangeRate-API (open access)",
        "attribution": "Rates By Exchange Rate API",
        "attributionUrl": "https://www.exchangerate-api.com",
        "disclaimer": (
            "Exchange rates are indicative third-party mid-market figures for information only. "
            "Not Bank of Botswana official rates. Not for settlement."
        ),
        "base": "USD",
        "pairs": pairs,
        "toZAR": to_zar,
        "status": "ok",
        "fetchedAt": now_iso(),
    }


# ---- SARB + manual rates ----

def fetch_sarb(env: Dict[str, str]) -> Dict[str, Dict[str, Any]]:
    url = env.get("SARB_URL", DEFAULTS["SARB_URL"])
    code, raw = http_get(url)
    if code != 200:
        raise RuntimeError(f"SARB HTTP {code}: {raw[:200]!r}")
    items = json.loads(raw.decode("utf-8"))
    by_name = {str(i.get("Name", "")).strip(): i for i in items}
    out: Dict[str, Dict[str, Any]] = {}
    if "SARB Policy Rate" in by_name:
        i = by_name["SARB Policy Rate"]
        out["repo-za"] = {
            "id": "repo-za",
            "name": "SARB repo rate",
            "last": float(i["Value"]),
            "unit": "%",
            "source": "SARB Web API",
            "asOf": i.get("Date"),
            "note": f"Official SARB Web API · as of {i.get('Date')} · Source: South African Reserve Bank",
            "manual": False,
        }
    if "Prime lending rate" in by_name:
        i = by_name["Prime lending rate"]
        out["prime-za"] = {
            "id": "prime-za",
            "name": "SA prime lending rate",
            "last": float(i["Value"]),
            "unit": "%",
            "source": "SARB Web API",
            "asOf": i.get("Date"),
            "note": f"Official SARB Web API · as of {i.get('Date')} · Source: South African Reserve Bank",
            "manual": False,
        }
    return out


def load_manual_pack(script_dir: Path) -> Dict[str, Any]:
    path = script_dir / "manual_rates.json"
    data = read_json_file(path) or {}
    return {
        "rates": list(data.get("rates") or []),
        "links": list(data.get("links") or []),
    }


# ---- Mansa ----

def mansa_get(env: Dict[str, str], path: str) -> Any:
    key = (env.get("MANSA_API_KEY") or "").strip()
    if not key:
        raise RuntimeError("MANSA_API_KEY not set")
    base = env.get("MANSA_BASE", DEFAULTS["MANSA_BASE"]).rstrip("/")
    code, raw = http_get(f"{base}{path}", headers={"Authorization": f"Bearer {key}"})
    if code != 200:
        raise RuntimeError(f"Mansa {path} HTTP {code}: {raw[:300]!r}")
    return json.loads(raw.decode("utf-8"))


def _index_match(row: Dict[str, Any], needles: List[str]) -> bool:
    blob = " ".join(str(row.get(k, "")) for k in ("code", "index_code", "name", "slug", "exchange")).lower()
    return all(n.lower() in blob for n in needles) or any(n.lower() == blob for n in needles)


def pick_indices(payload: Any) -> List[Dict[str, Any]]:
    """Map Mansa index rows to TopBuck board rows."""
    rows = payload.get("data", payload) if isinstance(payload, dict) else payload
    if not isinstance(rows, list):
        rows = []

    wanted = [
        ("jse-all", "JSE All Share", "ZA", ["jse", "all"]),
        ("jse-t40", "JSE Top 40", "ZA", ["jse", "top", "40"]),
        ("bse-dci", "BSE Domestic Company Index", "BW", ["bse", "domestic"]),
        ("nsx-ov", "NSX Overall Index", "NA", ["nsx", "overall"]),
    ]
    # Also try exchange-specific aliases
    aliases = {
        "jse-all": [["jse-asi"], ["jse all share"], ["all share"]],
        "jse-t40": [["top 40"], ["jse40"], ["jtopi"]],
        "bse-dci": [["bse-dci"], ["dci"], ["domestic company"]],
        "nsx-ov": [["nsx-oi"], ["nsx overall"], ["overall index"]],
    }

    found: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        name = str(row.get("name") or row.get("Name") or "")
        code = str(row.get("code") or row.get("index_code") or row.get("slug") or "")
        exch = str(row.get("exchange") or row.get("country") or "")
        value = row.get("value")
        if value is None:
            value = row.get("currentPrice") or row.get("last") or row.get("close")
        chg = row.get("change_pct")
        if chg is None:
            chg = row.get("changePercentage") or row.get("change")
        updated = row.get("updated_at") or row.get("currentDateTime")
        blob = f"{code} {name} {exch}".lower()

        for tid, tname, mkt, _ in wanted:
            if tid in found:
                continue
            ok = False
            for alias in aliases.get(tid, []):
                if all(a in blob for a in alias):
                    ok = True
                    break
            # exchange + keyword soft match
            if not ok and tid.startswith("jse") and "jse" in blob and ("all share" in blob or "asi" in blob) and tid == "jse-all":
                ok = True
            if not ok and tid == "jse-t40" and "jse" in blob and "40" in blob:
                ok = True
            if not ok and tid == "bse-dci" and ("bse" in blob or "botswana" in blob) and ("dci" in blob or "domestic" in blob):
                ok = True
            if not ok and tid == "nsx-ov" and ("nsx" in blob or "namibia" in blob) and ("overall" in blob or "oi" in blob):
                ok = True
            if ok and value is not None:
                try:
                    last = float(value)
                    chgf = float(chg) if chg is not None else None
                except (TypeError, ValueError):
                    continue
                note = "Delayed / indicative · Data by MansaAPI"
                if updated:
                    note = f"{note} · as of {updated}"
                found[tid] = {
                    "id": tid,
                    "name": tname,
                    "mkt": mkt,
                    "last": last,
                    "chg": chgf if chgf is not None else 0.0,
                    "seed": abs(hash(tid)) % 1000,
                    "note": note,
                    "updatedAt": updated,
                    "asOf": updated,
                }

    # Preserve board order
    return [found[tid] for tid, *_ in wanted if tid in found]


def pick_movers(payload: Any, exchange: str) -> List[Dict[str, Any]]:
    rows = payload.get("data", payload) if isinstance(payload, dict) else payload
    if isinstance(rows, dict):
        # some APIs nest gainers/losers
        merged = []
        for k in ("gainers", "losers", "movers", "both"):
            if isinstance(rows.get(k), list):
                merged.extend(rows[k])
        rows = merged or list(rows.values())
    if not isinstance(rows, list):
        return []
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = row.get("name") or row.get("company") or row.get("ticker") or row.get("symbol")
        last = row.get("price") or row.get("last") or row.get("close") or row.get("value")
        chg = row.get("change_pct") or row.get("changePercentage") or row.get("change")
        if name is None or last is None:
            continue
        try:
            out.append({
                "name": str(name),
                "mkt": exchange,
                "last": float(last),
                "chg": float(chg) if chg is not None else 0.0,
            })
        except (TypeError, ValueError):
            continue
    return out


def mansa_should_skip(state_dir: Path, min_age_min: int = 110) -> Tuple[bool, Optional[Dict[str, Any]]]:
    """Skip Mansa calls if last successful fetch is fresher than min_age_min (Free = 100 req/day)."""
    meta = read_json_file(state_dir / "mansa.last-ok.json") or {}
    ts = meta.get("okAtUnix")
    if not ts:
        return False, meta
    try:
        age = time.time() - float(ts)
    except (TypeError, ValueError):
        return False, meta
    if age < min_age_min * 60:
        return True, meta
    return False, meta


def fetch_markets(
    env: Dict[str, str],
    script_dir: Path,
    prev: Optional[Dict[str, Any]],
    state_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    errors: List[str] = []
    indices: List[Dict[str, Any]] = []
    movers: List[Dict[str, Any]] = []
    mansa_ok = False
    mansa_skipped = False

    if (env.get("MANSA_API_KEY") or "").strip():
        skip, _meta = mansa_should_skip(state_dir or Path("/tmp"), 110) if state_dir else (False, None)
        if skip and prev and (prev.get("indices") or prev.get("movers")):
            mansa_skipped = True
            indices = list(prev.get("indices") or [])
            movers = list(prev.get("movers") or [])
            mansa_ok = bool(indices or movers)
            errors.append("Mansa skipped — last successful fetch under 110 minutes (quota guard)")
        else:
            try:
                # 6 calls max: per-exchange indices + movers (skip global /markets/indices)
                for exch in ("JSE", "BSE", "NSX"):
                    try:
                        p = mansa_get(env, f"/markets/exchanges/{exch}/indices")
                        extra = pick_indices({"data": p.get("data", p) if isinstance(p, dict) else p})
                        have = {i["id"] for i in indices}
                        for e in extra:
                            if e["id"] not in have:
                                indices.append(e)
                            else:
                                # Prefer row with updatedAt if we already had a weaker match
                                for i, old in enumerate(indices):
                                    if old["id"] == e["id"] and e.get("updatedAt") and not old.get("updatedAt"):
                                        indices[i] = e
                    except Exception as ex:
                        errors.append(f"{exch} indices: {ex}")
                for exch, lim in (("JSE", 6), ("BSE", 4), ("NSX", 4)):
                    try:
                        p = mansa_get(env, f"/markets/exchanges/{exch}/movers?limit={lim}&type=both")
                        movers.extend(pick_movers(p, exch))
                    except Exception as ex:
                        errors.append(f"{exch} movers: {ex}")
                mansa_ok = bool(indices or movers)
                if mansa_ok and state_dir is not None:
                    atomic_write(state_dir / "mansa.last-ok.json", {
                        "okAt": now_iso(),
                        "okAtUnix": time.time(),
                        "indexCount": len(indices),
                        "moverCount": len(movers),
                    })
            except Exception as ex:
                errors.append(f"Mansa: {ex}")
    else:
        errors.append("MANSA_API_KEY missing — equities skipped")

    # Rates: SARB live + manual
    rates_map: Dict[str, Dict[str, Any]] = {}
    try:
        rates_map.update(fetch_sarb(env))
    except Exception as ex:
        errors.append(f"SARB: {ex}")
    manual = load_manual_pack(script_dir)
    for r in manual["rates"]:
        # Hard ban: never publish BoB rate figures on the board
        rid = str(r.get("id") or "")
        name = str(r.get("name") or "").lower()
        src = str(r.get("source") or "").lower()
        if rid.startswith("mopr") or "bank of botswana" in src or "bob " in name or name.startswith("bob"):
            continue
        rates_map[r["id"]] = r
    rates = list(rates_map.values())
    order = ["repo-za", "prime-za", "repo-na", "cpi-za", "cpi-bw", "cpi-na"]
    rates.sort(key=lambda r: order.index(r["id"]) if r["id"] in order else 99)
    outbound_links = manual.get("links") or []

    status = "ok"
    if not mansa_ok and not indices:
        # Keep previous equities if present
        if prev and prev.get("indices"):
            indices = prev["indices"]
            movers = prev.get("movers") or []
            status = "stale"
        else:
            status = "partial" if rates else "unavailable"
    elif errors and not mansa_skipped:
        status = "partial"
    elif mansa_skipped:
        status = "ok" if indices else status

    if status == "stale" and prev:
        as_of = prev.get("asOf") or now_iso()
    else:
        as_of = now_iso()

    return {
        "asOf": as_of,
        "fetchedAt": now_iso(),
        "zone": ZONE_LABEL,
        "status": status,
        "errors": errors,
        "attribution": "Data by MansaAPI",
        "attributionUrl": "https://mansaapi.com",
        "disclaimer": (
            "Market prices are delayed / indicative, not live. Data by MansaAPI. "
            "Not for trading execution. Cosmic Technologies is not licensed to give financial advice. "
            "Not official BSE / JSE / NSX data and not exchange-licensed."
        ),
        "jseDelayNote": (
            "JSE data delayed by at least 15 minutes (or as refreshed by our data provider) "
            "and must not be treated as real-time."
        ),
        "cachePolicy": "Cache at most 24 hours on Mansa Free. Do not resell raw feed.",
        "panels": {
            "equities": (
                "ok" if (mansa_ok and indices) else
                ("stale" if indices else "unavailable")
            ),
            "rates": "ok" if rates else "unavailable",
            "commodities": "unavailable",
        },
        "mansaSkipped": mansa_skipped,
        "indices": indices,
        "movers": movers[:12],
        "rates": rates,
        "links": outbound_links,
        "commodities": [],  # not wired on free stack (quota + licensing path TBD)
    }


# ---- Currents news ----

def currents_get(env: Dict[str, str], path: str, params: Dict[str, str]) -> Any:
    key = (env.get("CURRENTS_API_KEY") or "").strip()
    if not key:
        raise RuntimeError("CURRENTS_API_KEY not set")
    base = env.get("CURRENTS_BASE", DEFAULTS["CURRENTS_BASE"]).rstrip("/")
    q = urllib.parse.urlencode(params)
    # Currents accepts Authorization Bearer
    code, raw = http_get(f"{base}{path}?{q}", headers={"Authorization": f"Bearer {key}"})
    if code != 200:
        raise RuntimeError(f"Currents {path} HTTP {code}: {raw[:300]!r}")
    return json.loads(raw.decode("utf-8"))


def source_from_url(url: str) -> str:
    try:
        host = urllib.parse.urlparse(url).hostname or ""
    except Exception:
        host = ""
    host = host.lower()
    if host.startswith("www."):
        host = host[4:]
    return host or "Publisher"


def is_india_noise(title: str, url: str, dek: str = "") -> bool:
    blob = f"{title} {url} {dek}".lower()
    needles = (
        "sensex", "nifty", "bombay", "mumbai", " bse sensex", "nse india",
        "nse:", "rs.", "₹", " crore", "crores", "rupee", "india stock",
        "dalal street", "bse ltd", "bombay stock",
    )
    if any(n in blob for n in needles):
        return True
    # Bare "BSE" without Botswana / Domestic Company context → likely Bombay
    if "bse" in blob and not any(x in blob for x in ("botswana", "gaborone", "domestic compan", "bse.co.bw", "pula")):
        # Allow if clearly southern Africa
        if not any(x in blob for x in ("south africa", "namibia", "jse", "nsx", "rand", "windhoek")):
            return True
    return False


def is_pr_or_profile_piece(title: str, dek: str = "") -> bool:
    blob = f"{title} {dek}".lower()
    patterns = (
        r"\bapproach to\b",
        r"\bvisionary leadership\b",
        r"\bleadership profile\b",
        r"\bexpanding educational opportunity\b",
        r"\bmeet the\b",
        r"\bin conversation with\b",
        r"\bhow .+ became\b",
        r"\bceo spotlight\b",
        r"\bfounder story\b",
        r"\bwhere finance meets the customer experience\b",
    )
    if any(re.search(pat, blob) for pat in patterns):
        return True
    if re.search(r"^[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3}\s+[–—-]\s+", title):
        if not any(k in blob for k in ("south africa", "botswana", "namibia", "jse", "rand", "pula", "nedbank", "sasol")):
            return True
    return False


def has_sa_business_signal(title: str, url: str, dek: str = "") -> bool:
    """Title or description must mention a southern-Africa business signal (not merely .co.za host)."""
    blob = f"{title} {dek}".lower()
    geo = (
        "south africa", "south african", "johannesburg", "pretoria", "cape town",
        "botswana", "gaborone", "namibia", "windhoek", "namibian",
        "sarb", "bank of namibia", "namibian dollar", "namibia dollar",
    )
    if any(g in blob for g in geo):
        return True
    for pat in (r"\bjse\b", r"\bnsx\b", r"\brand\b", r"\bpula\b", r"\bzar\b", r"\bbwp\b", r"\bnad\b", r"\bsacu\b", r"\bsadc\b"):
        if re.search(pat, blob):
            return True
    companies = (
        "nedbank", "standard bank", "fnb", "absa", "capitec", "sasol", "naspers",
        "mtn", "vodacom", "debswana", "sefalana", "letshego", "old mutual", "sanlam",
        "remgro", "shoprite", "anglo american", "bank windhoek", "choppies",
        "first national bank", "investec", "bidvest", "botswana insurance", "fnbb", "stanbic",
        "tfg africa", "sixty60",
    )
    if any(c in blob for c in companies):
        return True
    if re.search(r"\bbse\b", blob) and any(x in blob for x in ("botswana", "gaborone", "domestic", "pula")):
        return True
    return False


def has_business_finance_term(title: str, dek: str = "") -> bool:
    blob = f"{title} {dek}".lower()
    terms = (
        r"\bbanks?\b", r"\bbanking\b", r"\bfinance\b", r"\bfinancial\b", r"\bmarkets?\b",
        r"\beconomy\b", r"\beconomic\b", r"\binflation\b", r"\binterest rates?\b", r"\brepo rate\b",
        r"\bprime rate\b", r"\bcurrency\b", r"\bexchange rates?\b", r"\bstocks?\b", r"\bequity\b",
        r"\bshares?\b", r"\bipo\b", r"\bearnings\b", r"\brevenue\b", r"\bprofits?\b", r"\bloss\b",
        r"\binvest(?:ment|or|ing)?\b", r"\blending\b", r"\bloans?\b", r"\bcredit\b",
        r"\binsurance\b", r"\bpension\b", r"\bretirement\b", r"\btax(?:es|ation)?\b", r"\bbudget\b",
        r"\bgdp\b", r"\btrade\b", r"\bexports?\b", r"\bimports?\b", r"\bfuel prices?\b", r"\bmining\b",
        r"\bdividends?\b", r"\bbonds?\b", r"\btreasury\b", r"\bmonetary\b", r"\bfiscal\b",
        r"\bsmes?\b", r"\bbusiness(?:es)?\b", r"\bcompan(?:y|ies)\b", r"\bcorporate\b", r"\blisting\b",
        r"\bsales?\b", r"\bpartnership\b", r"\brewards?\b", r"\bconsumer spending\b", r"\bretail\b",
        r"\bgeneration facilities\b", r"\bonline sales\b",
    )
    return any(re.search(pat, blob) for pat in terms)


def is_southern_africa_relevant(title: str, url: str, dek: str = "") -> bool:
    if is_pr_or_profile_piece(title, dek):
        return False
    if not has_sa_business_signal(title, url, dek):
        return False
    if not has_business_finance_term(title, dek):
        return False
    return True


def normalize_news_item(row: Dict[str, Any], idx: int) -> Optional[Dict[str, Any]]:
    title = (row.get("title") or "").strip()
    url = (row.get("url") or row.get("link") or "").strip()
    if not title or not url:
        return None
    dek = (row.get("description") or row.get("dek") or "")[:180]
    if is_india_noise(title, url, dek):
        return None
    if not is_southern_africa_relevant(title, url, dek):
        return None
    # Never store full article body
    author = row.get("author") or row.get("source") or ""
    if isinstance(author, list):
        author = ", ".join(str(s) for s in author[:2])
    author = str(author or "").strip()
    source = author if author and author.lower() not in ("none", "null", "n/a") else source_from_url(url)
    if not source or source.lower() in ("none", "null"):
        source = source_from_url(url)
    published = row.get("published") or row.get("publishedAt") or row.get("date") or ""
    cats = row.get("category") or row.get("categories") or []
    if isinstance(cats, str):
        cat = cats
    elif isinstance(cats, list) and cats:
        cat = str(cats[0])
    else:
        cat = "News"
    return {
        "id": f"live-{idx}",
        "type": "news",
        "cat": str(cat)[:40],
        "title": title[:240],
        "dek": dek,
        "date": str(published)[:40],
        "author": str(source)[:80],
        "source": str(source)[:80],
        "url": url,
        "external": True,
        "mins": 1,
    }


def fetch_news(env: Dict[str, str], prev: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    errors: List[str] = []
    items: List[Dict[str, Any]] = []
    if not (env.get("CURRENTS_API_KEY") or "").strip():
        errors.append("CURRENTS_API_KEY missing — news skipped")
    else:
        # Currents regions include ZA but not BW/NA — use country=ZA for SA business,
        # and keyword queries for Botswana / Namibia, then filter India noise.
        queries = [
            {"language": "en", "country": "ZA", "category": "business", "page_size": "15"},
            {"language": "en", "country": "ZA", "category": "finance", "page_size": "10"},
            {"keywords": "Botswana OR Gaborone OR \"Botswana Stock\" OR pula", "language": "en", "page_size": "10"},
            {"keywords": "Namibia OR Windhoek OR Namibian OR \"Bank Windhoek\" OR NSX", "language": "en", "page_size": "10"},
            {"keywords": "JSE OR Johannesburg OR \"South Africa\" economy OR rand", "language": "en", "country": "ZA", "page_size": "10"},
        ]
        seen = set()
        idx = 0
        for q in queries:
            try:
                payload = currents_get(env, "/search", q)
                rows = payload.get("news") or payload.get("articles") or payload.get("data") or []
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    url = (row.get("url") or "").strip()
                    if not url or url in seen:
                        continue
                    item = normalize_news_item(row, idx)
                    if not item:
                        continue
                    seen.add(url)
                    items.append(item)
                    idx += 1
                    if len(items) >= 20:
                        break
            except Exception as ex:
                errors.append(f"Currents search: {ex}")
            if len(items) >= 20:
                break
        # Prefer up to 15; if fewer than 6 remain, show what remains (no padding)
        items = items[:15]

    status = "ok" if items else ("stale" if prev and prev.get("items") else "unavailable")
    if status == "stale":
        items = prev.get("items") or []
        as_of = prev.get("asOf") or now_iso()
    else:
        as_of = now_iso()

    return {
        "asOf": as_of,
        "fetchedAt": now_iso(),
        "zone": ZONE_LABEL,
        "status": status if not errors else ("partial" if items else status),
        "errors": errors,
        "attribution": "Powered by Currents News API",
        "attributionUrl": "https://currentsapi.services/",
        "disclaimer": (
            "Headlines and links only. Powered by Currents News API. "
            "Full articles remain with the original publisher — follow the link to read. "
            "No full-text republication."
        ),
        "items": items[:15],
    }


def keep_or_write(path: Path, fresh: Dict[str, Any], kind: str) -> Dict[str, Any]:
    """If fresh status is unavailable and we have previous good data, keep previous with stale label."""
    prev = read_json_file(path)
    if fresh.get("status") in ("unavailable",) and prev and prev.get("status") in ("ok", "partial", "stale"):
        stale = dict(prev)
        stale["status"] = "stale"
        stale["fetchedAt"] = now_iso()
        stale["staleReason"] = f"Latest {kind} fetch failed; showing last good data"
        atomic_write(path, stale)
        return stale
    atomic_write(path, fresh)
    return fresh


def main() -> int:
    script_dir = Path(__file__).resolve().parent
    # Allow local override via env for testing
    env_file = Path(os.environ.get("TOPBUCK_FEEDS_ENV", DEFAULTS["ENV_FILE"]))
    env = load_env(env_file)
    # Local defaults when OUT_DIR overridden
    out_dir = Path(os.environ.get("OUT_DIR", env.get("OUT_DIR", DEFAULTS["OUT_DIR"])))
    state_dir = Path(os.environ.get("STATE_DIR", env.get("STATE_DIR", DEFAULTS["STATE_DIR"])))
    state_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    summary = {"started": now_iso(), "out": str(out_dir), "results": {}}

    # FX
    fx_path = out_dir / "fx.json"
    try:
        fx = fetch_fx(env, read_json_file(fx_path))
        atomic_write(fx_path, fx)
        # also keep state copy for chg calc next run
        atomic_write(state_dir / "fx.last.json", fx)
        summary["results"]["fx"] = fx["status"]
        print(f"OK fx.json status={fx['status']} pairs={len(fx['pairs'])}")
    except Exception as ex:
        print(f"FAIL fx: {ex}", file=sys.stderr)
        prev = read_json_file(fx_path)
        if prev:
            prev = dict(prev)
            prev["status"] = "stale"
            prev["fetchedAt"] = now_iso()
            prev["staleReason"] = str(ex)
            atomic_write(fx_path, prev)
            summary["results"]["fx"] = "stale"
            print("Kept previous fx.json as stale")
        else:
            summary["results"]["fx"] = "failed"
            # Never invent example numbers
            atomic_write(fx_path, {
                "asOf": None,
                "status": "unavailable",
                "pairs": [],
                "toZAR": {},
                "disclaimer": "FX feed unavailable.",
                "errors": [str(ex)],
                "fetchedAt": now_iso(),
            })

    # Markets
    m_path = out_dir / "markets.json"
    try:
        markets = fetch_markets(env, script_dir, read_json_file(m_path), state_dir)
        keep_or_write(m_path, markets, "markets")
        summary["results"]["markets"] = markets["status"]
        print(f"OK markets.json status={markets['status']} indices={len(markets['indices'])} rates={len(markets['rates'])}")
    except Exception as ex:
        print(f"FAIL markets: {ex}", file=sys.stderr)
        summary["results"]["markets"] = "failed"
        prev = read_json_file(m_path)
        if prev:
            prev = dict(prev)
            prev["status"] = "stale"
            prev["fetchedAt"] = now_iso()
            prev["staleReason"] = str(ex)
            atomic_write(m_path, prev)

    # News
    n_path = out_dir / "news.json"
    try:
        news = fetch_news(env, read_json_file(n_path))
        keep_or_write(n_path, news, "news")
        summary["results"]["news"] = news["status"]
        print(f"OK news.json status={news['status']} items={len(news['items'])}")
    except Exception as ex:
        print(f"FAIL news: {ex}", file=sys.stderr)
        summary["results"]["news"] = "failed"
        prev = read_json_file(n_path)
        if prev:
            prev = dict(prev)
            prev["status"] = "stale"
            prev["fetchedAt"] = now_iso()
            prev["staleReason"] = str(ex)
            atomic_write(n_path, prev)

    summary["finished"] = now_iso()
    atomic_write(state_dir / "last-run.json", summary)
    # Non-zero only if FX (keyless) hard-failed with no prior — soft for missing keys
    if summary["results"].get("fx") == "failed":
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
