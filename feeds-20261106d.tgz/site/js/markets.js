document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart, tab = 'indices', sel = null, range = 90;
  var meta = (window.TB_FEEDS && TB_FEEDS.meta().markets) || {};
  var fxMeta = (window.TB_FEEDS && TB_FEEDS.meta().fx) || {};
  var groups = { indices: ['Indices', D.indices], fx: ['Currencies', D.fx], commodities: ['Commodities', D.commodities] };

  function liveOk(st) { return st === 'ok' || st === 'partial' || st === 'stale'; }
  function equitiesLive() {
    var panels = (D.live && D.live.markets && D.live.markets.panels) || {};
    if (panels.equities) return liveOk(panels.equities) && D.indices && D.indices.length;
    return liveOk(meta.status) && D.indices && D.indices.length;
  }
  function fxLive() {
    return liveOk(fxMeta.status || (D.live && D.live.status && D.live.status.fx)) && D.fx && D.fx.length;
  }
  function show(sel, on) {
    document.querySelectorAll(sel).forEach(function (el) { el.hidden = !on; });
  }
  function applyLabels() {
    var eq = equitiesLive(), fx = fxLive();
    var eyebrow = document.getElementById('m-eyebrow');
    if (eyebrow) eyebrow.textContent = eq ? 'Delayed / indicative' : 'Markets';
    var ex = document.getElementById('m-ex-tag');
    // No example equity numbers on screen — use coming-soon, not Example tag over fake prices
    if (ex) ex.hidden = true;
    show('.feed-live-equities', eq);
    show('.feed-live-fx', fx);
    var soon = document.getElementById('m-equities-soon');
    if (soon) soon.hidden = eq;
    var stEl = document.getElementById('m-status');
    if (stEl) {
      var bits = [];
      if (eq) bits.push('Equities: ' + (meta.status || 'ok') + (meta.asOf ? ' · as of ' + TB_FEEDS.asOfText(meta.asOf) : ''));
      else bits.push('Equities: live data coming soon');
      if (fx) bits.push('FX: ' + (fxMeta.status || 'ok') + (fxMeta.asOf ? ' · as of ' + TB_FEEDS.asOfText(fxMeta.asOf) : ''));
      stEl.textContent = bits.join(' · ');
    }
  }

  function indexAsOf(i) {
    var raw = i.asOf || i.updatedAt;
    if (!raw) return '';
    try {
      if (window.TB_FEEDS && TB_FEEDS.asOfText) return TB_FEEDS.asOfText(raw);
      return String(raw);
    } catch (e) { return String(raw); }
  }
  function series(i, n) {
    var raw = D.series(i.seed, n, 100, i.id.indexOf('fx') > -1 ? 0.002 : 0.006, 0);
    var k = i.last / raw[n - 1];
    return raw.map(function (v) { return v * k; });
  }
  function table() {
    var g = groups[tab];
    // Hide live equity credits when on FX tab context for chart credit swap
    show('.feed-live-equities', equitiesLive() && tab !== 'fx');
    show('.feed-live-fx', fxLive() && (tab === 'fx' || equitiesLive()));
    if (tab === 'fx') show('.feed-live-fx', fxLive());
    if (tab === 'commodities' || (tab === 'indices' && !equitiesLive())) {
      if (tab === 'indices' && !equitiesLive()) {
        document.getElementById('mtable').innerHTML = '<tbody><tr><td class="muted">Live equity indices coming soon (Mansa API key required). No example prices are shown as live.</td></tr></tbody>';
        return;
      }
      if (tab === 'commodities') {
        document.getElementById('mtable').innerHTML = '<tbody><tr><td class="muted">Commodities live data coming soon — not on the free stack yet.</td></tr></tbody>';
        return;
      }
    }
    if (!g[1] || !g[1].length) {
      document.getElementById('mtable').innerHTML = '<tbody><tr><td class="muted">No ' + g[0].toLowerCase() + ' in the latest feed.</td></tr></tbody>';
      return;
    }
    var th = '<thead><tr><th>Name</th><th>Last</th><th>Change</th><th>Trend</th></tr></thead>';
    document.getElementById('mtable').innerHTML = th + '<tbody>' + g[1].map(function (i) {
      var as = (tab === 'indices') ? indexAsOf(i) : '';
      return '<tr class="sel" data-id="' + i.id + '" style="cursor:pointer;' + (sel && sel.id === i.id ? 'background:rgba(214,170,75,.08)' : '') + '"><td><b>' + i.name + '</b>' + (as ? '<div class="small muted">as of ' + as + '</div>' : '') + '</td><td>' + TB.group(i.last, i.last >= 100 ? 1 : 2) + '</td><td>' + TB.chg(i.chg == null ? 0 : i.chg) + '</td><td>' + C.spark(series(i, 30), (i.chg || 0) >= 0 ? '#58C28A' : '#E4796B') + '</td></tr>';
    }).join('') + '</tbody>';
  }
  function chart() {
    if (!sel) {
      document.getElementById('mtitle').textContent = 'Select a row';
      document.getElementById('mchart').innerHTML = '';
      return;
    }
    if (tab === 'indices' && !equitiesLive()) {
      document.getElementById('mtitle').textContent = 'Live data coming soon';
      document.getElementById('mchart').innerHTML = '';
      return;
    }
    var s = series(sel, range), pts = s.map(function (v, i) { return [i - range + 1, v]; });
    var asTitle = (tab === 'indices' && indexAsOf(sel)) ? (' · as of ' + indexAsOf(sel)) : '';
    document.getElementById('mtitle').textContent = sel.name + (tab === 'fx' ? ' — indicative' : ' — delayed / indicative') + asTitle;
    C.line(document.getElementById('mchart'), { series: [{ name: sel.name, color: '#D6AA4B', pts: pts, area: true }], yMin: Math.min.apply(null, s) * 0.97, yFmt: function (v) { return TB.group(v, v >= 100 ? 0 : 2); }, xFmt: function (x) { return x === 0 ? 'Today' : Math.round(-x) + 'd ago'; }, tipFmt: function (v) { return TB.group(v, v >= 100 ? 1 : 3); }, label: tab === 'fx' ? 'Indicative FX' : 'Indicative (no licensed history on free tier)' });
  }
  function tabs() { document.getElementById('mtabs').innerHTML = Object.keys(groups).map(function (k) { return '<button type="button" data-k="' + k + '" aria-pressed="' + (k === tab) + '">' + groups[k][0] + '</button>'; }).join(''); }
  function ranges() { document.getElementById('mrange').innerHTML = [['1M', 30], ['3M', 90], ['1Y', 250]].map(function (r) { return '<button type="button" data-r="' + r[1] + '" aria-pressed="' + (r[1] === range) + '">' + r[0] + '</button>'; }).join(''); }

  // Default tab: FX if equities not live (so page isn't empty)
  if (!equitiesLive() && fxLive()) tab = 'fx';
  sel = (groups[tab][1] && groups[tab][1][0]) || null;
  applyLabels(); tabs(); ranges(); table(); if (sel) chart();

  document.getElementById('mtabs').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    tab = b.dataset.k; sel = (groups[tab][1] && groups[tab][1][0]) || null;
    tabs(); table(); if (sel) chart(); else { document.getElementById('mtitle').textContent = ''; document.getElementById('mchart').innerHTML = ''; }
    applyLabels();
  });
  document.getElementById('mtable').addEventListener('click', function (e) {
    var tr = e.target.closest('tr[data-id]'); if (!tr) return;
    sel = groups[tab][1].filter(function (i) { return i.id === tr.dataset.id; })[0];
    table(); chart();
  });
  document.getElementById('mrange').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return; range = +b.dataset.r; ranges(); chart();
  });

  var moversEl = document.getElementById('movers');
  if (moversEl) {
    moversEl.innerHTML = (equitiesLive() && D.movers && D.movers.length)
      ? D.movers.map(function (m) { return '<div class="mkt-row"><div><div class="nm">' + m.name + '</div><div class="sub">' + m.mkt + ' · delayed</div></div><div class="num">' + TB.group(m.last, 2) + '</div><div>' + TB.chg(m.chg) + '</div></div>'; }).join('')
      : '<p class="muted small">Movers appear when the Mansa feed is live.</p>';
  }

  // Rates: SARB + manual (no BoB figures) + outbound BoB link from feed
  var links = (D.live && D.live.markets && D.live.markets.links) || [];
  var bob = links.filter(function (l) { return l.id === 'bob-link'; })[0];
  var bobEl = document.getElementById('m-bob-link');
  if (bobEl && bob) {
    bobEl.innerHTML = '<a href="' + bob.url + '" rel="noopener" target="_blank">' + bob.text + '</a> (no BoB figures are republished here).';
  }
  var rateRows = (D.rates || []).filter(function (r) {
    var id = r.id || '', name = (r.name || '').toLowerCase(), note = (r.note || '').toLowerCase();
    if (id.indexOf('mopr') === 0 || id.indexOf('bob') === 0) return false;
    if (name.indexOf('bank of botswana') >= 0 || name.indexOf('bob ') === 0) return false;
    if (note.indexOf('bank of botswana') >= 0 && r.manual) return false;
    return true;
  });
  document.getElementById('rates').innerHTML = '<thead><tr><th>Rate</th><th>Level</th></tr></thead><tbody>' + rateRows.map(function (r) {
    return '<tr><td>' + r.name + '<div class="small muted">' + (r.note || '') + '</div></td><td><b>' + Number(r.last).toFixed(2) + (r.unit || '%') + '</b></td></tr>';
  }).join('') + '</tbody>';
});
