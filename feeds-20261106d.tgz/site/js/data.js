/* TopBuck static fallbacks. Markets/FX/news are replaced at runtime by /data/*.json from the server fetcher when present. Client CRM rows remain illustrative until auth ships. */
window.TB_DATA = (function () {
  var D = {};
  D.version = 'prototype-0.1';
  D.asOf = 'awaiting live feeds';
  // FX to ZAR (illustrative). NAD is pegged 1:1 to ZAR. BWP is a basket-managed crawling peg.
  D.ccy = {
    BWP: { code: 'BWP', sym: 'P',  name: 'Botswana pula',     toZAR: 1.32, country: 'BW', locale: 'en-BW' },
    ZAR: { code: 'ZAR', sym: 'R',  name: 'South African rand', toZAR: 1.00, country: 'ZA', locale: 'en-ZA' },
    NAD: { code: 'NAD', sym: 'N$', name: 'Namibia dollar',     toZAR: 1.00, country: 'NA', locale: 'en-NA' }
  };
  // Country assumption presets — illustrative starting points, NOT quotes. Verify against central bank / bank / fund sources.
  D.country = {
    BW: { name: 'Botswana', policyLabel: 'Policy rate (illustrative preset)', policy: 5.50, prime: 7.75, mortgage: 8.50, cpiNow: 7.8, infl: 5.0,
          preRet: 9.0, postRet: 7.0, schoolInfl: 6.0, uniInfl: 6.0, retNote: 'Example: BPOPF-style DC fund — 15% employer + 5% member of pensionable salary (verify with fund). Lump-sum share varies by fund rules.',
          lumpPct: 50, regs: 'NBFIRA / Retirement Funds Act 2022' },
    ZA: { name: 'South Africa', policyLabel: 'SARB repo rate', policy: 7.25, prime: 10.75, mortgage: 10.75, cpiNow: 4.5, infl: 4.5,
          preRet: 10.0, postRet: 7.5, schoolInfl: 7.0, uniInfl: 6.0, retNote: 'Two-pot: from 1 Sep 2024, one-third of new contributions go to a savings pot, two-thirds to a retirement pot. Regulation 28 caps equity at 75%, property 25% and offshore at 45%.',
          lumpPct: 33, regs: 'FSCA / Pension Funds Act / Reg 28' },
    NA: { name: 'Namibia', policyLabel: 'BoN repo rate', policy: 7.00, prime: 10.50, mortgage: 10.50, cpiNow: 5.4, infl: 4.5,
          preRet: 9.5, postRet: 7.5, schoolInfl: 6.5, uniInfl: 6.0, retNote: 'Example: Namibian pension funds are regulated by NAMFISA; the ZAR-linked market means offshore/ZAR exposure is common.',
          lumpPct: 33, regs: 'NAMFISA' }
  };
  // seeded PRNG so charts/sparklines are stable
  function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; var t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };
  D.series = function (seed, n, start, vol, drift) {
    var r = rng(seed), v = start, out = [];
    for (var i = 0; i < n; i++) { v = v * (1 + (r() - 0.5) * vol + (drift || 0)); out.push(v); }
    // scale so the final point equals the stated last value (set by caller)
    return out;
  };
  D.indices = [];
  D.fx = [
    { id: 'usdzar', name: 'USD / ZAR', last: 17.82, chg: -0.28, seed: 21 },
    { id: 'usdbwp', name: 'USD / BWP', last: 13.49, chg: -0.10, seed: 22 },
    { id: 'usdnad', name: 'USD / NAD', last: 17.82, chg: -0.28, seed: 23 },
    { id: 'eurzar', name: 'EUR / ZAR', last: 20.64, chg: 0.09, seed: 24 },
    { id: 'gbpzar', name: 'GBP / ZAR', last: 23.71, chg: 0.15, seed: 25 },
    { id: 'bwpzar', name: 'BWP / ZAR', last: 1.32, chg: 0.02, seed: 26 }
  ];
  D.commodities = [];
  D.rates = [
    { id: 'repo-za', name: 'SARB repo rate', last: 7.25, unit: '%', note: 'Awaiting live SARB feed' },
    { id: 'prime-za', name: 'SA prime lending rate', last: 10.75, unit: '%', note: 'Awaiting live SARB feed' },
    { id: 'repo-na', name: 'BoN repo rate', last: 7.00, unit: '%', note: 'Manual · Source: Bank of Namibia' },
    { id: 'cpi-za', name: 'SA headline CPI (y/y)', last: 4.5, unit: '%', note: 'Manual · Source: Stats SA' },
    { id: 'cpi-bw', name: 'Botswana headline CPI (y/y)', last: 7.8, unit: '%', note: 'Manual · Source: Statistics Botswana' },
    { id: 'cpi-na', name: 'Namibia headline CPI (y/y)', last: 5.4, unit: '%', note: 'Manual · Source: NSA' }
  ];
  D.movers = [];
  // Live news comes from /data/news.json (Currents). Insights can be added editorially later.
  D.news = [];
  D.learn = [
    { t: 'Compound interest in plain language', k: 'Basics', m: 4 }, { t: 'How a home loan really works', k: 'Property', m: 6 }, { t: 'What is Regulation 28?', k: 'Retirement', m: 5 },
    { t: 'Education inflation explained', k: 'Education', m: 4 }, { t: 'Depreciation: what happens to a car’s value', k: 'Motoring', m: 5 }, { t: 'Advice vs information: what clients should know', k: 'Compliance', m: 4 }
  ];
  // Example clients (invented). ccy = client's home currency. Scenario params are in that currency.
  D.clients = [
    { id: 'c1', name: 'Thandi Moloi', age: 41, ccy: 'ZAR', aum: 2850000, risk: 'Moderate', review: '12 Oct 2026', status: 'On track', goal: 68, tag: 'Retirement', email: 'thandi@example.com' },
    { id: 'c2', name: 'Kabelo Seretse', age: 36, ccy: 'BWP', aum: 640000, risk: 'Moderately aggressive', review: '29 Sep 2026', status: 'Review due', goal: 44, tag: 'Home loan', email: 'kabelo@example.com' },
    { id: 'c3', name: 'Anneli Shikongo', age: 49, ccy: 'NAD', aum: 4120000, risk: 'Moderate', review: '03 Oct 2026', status: 'On track', goal: 81, tag: 'Retirement', email: 'anneli@example.com' },
    { id: 'c4', name: 'Pieter van Wyk', age: 33, ccy: 'ZAR', aum: 410000, risk: 'Aggressive', review: '21 Aug 2026', status: 'Review due', goal: 29, tag: 'Education', email: 'pieter@example.com' },
    { id: 'c5', name: 'Naledi Dube', age: 54, ccy: 'BWP', aum: 3380000, risk: 'Conservative', review: '15 Oct 2026', status: 'On track', goal: 90, tag: 'Retirement', email: 'naledi@example.com' },
    { id: 'c6', name: 'Joseph Haufiku', age: 29, ccy: 'NAD', aum: 185000, risk: 'Aggressive', review: '07 Sep 2026', status: 'Needs attention', goal: 18, tag: 'Vehicle', email: 'joseph@example.com' },
    { id: 'c7', name: 'Lerato Nkosi', age: 45, ccy: 'ZAR', aum: 1960000, risk: 'Moderate', review: '26 Oct 2026', status: 'On track', goal: 57, tag: 'Education', email: 'lerato@example.com' },
    { id: 'c8', name: 'Tshepo Kgosi', age: 38, ccy: 'BWP', aum: 920000, risk: 'Moderate', review: '30 Sep 2026', status: 'Review due', goal: 51, tag: 'Home loan', email: 'tshepo@example.com' }
  ];
  D.scenarios = [
    { id: 's1', client: 'c1', type: 'retirement', label: 'Retire at 63, R35k target', date: '12 Oct 2026', ccy: 'ZAR', params: { age: 41, retAge: 63, planAge: 90, savings: 1450000, monthly: 9500, escal: 5, preRet: 10, postRet: 7.5, infl: 4.5, targetIncome: 35000, salary: 62000, twoPot: true } },
    { id: 's2', client: 'c1', type: 'retirement', label: 'Retire at 65, same target', date: '12 Oct 2026', ccy: 'ZAR', params: { age: 41, retAge: 65, planAge: 90, savings: 1450000, monthly: 9500, escal: 5, preRet: 10, postRet: 7.5, infl: 4.5, targetIncome: 35000, salary: 62000, twoPot: true } },
    { id: 's3', client: 'c2', type: 'mortgage', label: 'P1.4m home, 10% deposit', date: '29 Sep 2026', ccy: 'BWP', params: { price: 1400000, depositPct: 10, rate: 8.5, years: 20, extra: 0 } },
    { id: 's4', client: 'c2', type: 'mortgage', label: 'Same, +P1,000/month extra', date: '29 Sep 2026', ccy: 'BWP', params: { price: 1400000, depositPct: 10, rate: 8.5, years: 20, extra: 1000 } },
    { id: 's5', client: 'c3', type: 'retirement', label: 'Retire at 62', date: '03 Oct 2026', ccy: 'NAD', params: { age: 49, retAge: 62, planAge: 90, savings: 3200000, monthly: 16000, escal: 5, preRet: 9.5, postRet: 7.5, infl: 4.5, targetIncome: 60000, salary: 110000, twoPot: false } },
    { id: 's6', client: 'c4', type: 'education', label: 'Daughter, age 4 — private school + uni', date: '21 Aug 2026', ccy: 'ZAR', params: { childAge: 4, schoolStartAge: 6, schoolYears: 12, schoolFee: 75000, schoolInfl: 7, uniStartAge: 18, uniYears: 3, uniFee: 70000, uniInfl: 6, savings: 15000, ret: 9 } },
    { id: 's7', client: 'c5', type: 'retirement', label: 'Retire at 60 (BPOPF-style DC)', date: '15 Oct 2026', ccy: 'BWP', params: { age: 54, retAge: 60, planAge: 88, savings: 2900000, monthly: 12000, escal: 3, preRet: 9, postRet: 7, infl: 5, targetIncome: 22000, salary: 48000, twoPot: false } },
    { id: 's8', client: 'c6', type: 'car', label: 'Used Hilux — trade-in check', date: '07 Sep 2026', ccy: 'NAD', params: { model: 'hilux', year: 2020, mileage: 118000, condition: 'Good', marketAdj: 0 } },
    { id: 's9', client: 'c7', type: 'education', label: 'Son, age 9', date: '26 Oct 2026', ccy: 'ZAR', params: { childAge: 9, schoolStartAge: 6, schoolYears: 12, schoolFee: 58000, schoolInfl: 7, uniStartAge: 18, uniYears: 4, uniFee: 82000, uniInfl: 6, savings: 60000, ret: 9 } },
    { id: 's10', client: 'c8', type: 'mortgage', label: 'P2.1m home, 15 years', date: '30 Sep 2026', ccy: 'BWP', params: { price: 2100000, depositPct: 15, rate: 8.5, years: 15, extra: 0 } }
  ];
  // Car models — illustrative list prices in ZAR (NOT manufacturer or dealer prices) and segment depreciation assumptions.
  D.cars = [
    { id: 'hilux', make: 'Toyota', model: 'Hilux 2.4 GD-6 double cab', newZAR: 640000, d1: 0.12, d: 0.08, seg: 'Bakkie' },
    { id: 'ranger', make: 'Ford', model: 'Ranger 2.0 BiT double cab', newZAR: 850000, d1: 0.15, d: 0.09, seg: 'Bakkie' },
    { id: 'dmax', make: 'Isuzu', model: 'D-Max 1.9 double cab', newZAR: 590000, d1: 0.14, d: 0.09, seg: 'Bakkie' },
    { id: 'fortuner', make: 'Toyota', model: 'Fortuner 2.8 GD-6', newZAR: 830000, d1: 0.12, d: 0.08, seg: 'SUV' },
    { id: 'corolla-cross', make: 'Toyota', model: 'Corolla Cross 1.8 XS', newZAR: 440000, d1: 0.13, d: 0.09, seg: 'SUV' },
    { id: 'polo', make: 'Volkswagen', model: 'Polo 1.0 TSI', newZAR: 365000, d1: 0.17, d: 0.10, seg: 'Hatchback' },
    { id: 'swift', make: 'Suzuki', model: 'Swift 1.2 GL', newZAR: 245000, d1: 0.14, d: 0.09, seg: 'Hatchback' },
    { id: 'i20', make: 'Hyundai', model: 'i20 1.2 Motion', newZAR: 295000, d1: 0.16, d: 0.10, seg: 'Hatchback' },
    { id: 'jolion', make: 'Haval', model: 'Jolion 1.5T Premium', newZAR: 460000, d1: 0.19, d: 0.11, seg: 'SUV' },
    { id: 'cx5', make: 'Mazda', model: 'CX-5 2.0 Dynamic', newZAR: 560000, d1: 0.16, d: 0.10, seg: 'SUV' },
    { id: 'navara', make: 'Nissan', model: 'Navara 2.5 DDTi double cab', newZAR: 620000, d1: 0.17, d: 0.10, seg: 'Bakkie' },
    { id: 'c200', make: 'Mercedes-Benz', model: 'C200 sedan', newZAR: 940000, d1: 0.20, d: 0.12, seg: 'Premium sedan' }
  ];
  return D;
})();
