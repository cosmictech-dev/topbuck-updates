/* Tiny dependency-free SVG charts for TopBuck (line/area, stacked columns, sparklines). */
window.TBChart = (function () {
  var NS = 'http://www.w3.org/2000/svg';
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function niceMax(v) { if (v <= 0) return 1; var p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p; var n = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10; return n * p; }
  function ticksY(max, n) { var a = []; for (var i = 0; i <= n; i++) a.push(max * i / n); return a; }
  function pick(len, k) { if (len <= k) return Array.from({ length: len }, function (_, i) { return i; }); var idx = []; for (var i = 0; i < k; i++) idx.push(Math.round(i * (len - 1) / (k - 1))); return idx; }
  var uid = 0;
  function mount(el, draw) {
    el.classList.add('chart');
    function render() { var w = Math.max(280, el.clientWidth || 600); draw(w); }
    render();
    if (typeof ResizeObserver !== 'undefined') { var last = el.clientWidth, t; new ResizeObserver(function () { if (Math.abs(el.clientWidth - last) < 4) return; last = el.clientWidth; clearTimeout(t); t = setTimeout(render, 80); }).observe(el); }
  }
  /* line({series:[{name,color,pts:[[x,y]],area,dash}], xFmt, yFmt, xTicks, yMin, vline:{x,label}}) */
  function line(el, o) {
    mount(el, function (W) {
      var H = W < 520 ? 260 : 330, m = { l: W < 520 ? 52 : 64, r: 14, t: 14, b: 30 };
      var all = [].concat.apply([], o.series.map(function (s) { return s.pts; }));
      var xs = all.map(function (p) { return p[0]; }), ys = all.map(function (p) { return p[1]; });
      var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs);
      var yMin = o.yMin != null ? o.yMin : Math.min(0, Math.min.apply(null, ys)), yMax = niceMax(Math.max.apply(null, ys));
      var X = function (x) { return m.l + (x - x0) / ((x1 - x0) || 1) * (W - m.l - m.r); };
      var Y = function (y) { return H - m.b - (y - yMin) / ((yMax - yMin) || 1) * (H - m.t - m.b); };
      var id = 'g' + (++uid), h = '';
      h += '<defs>' + o.series.map(function (s, i) { return '<linearGradient id="' + id + i + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + s.color + '" stop-opacity=".30"/><stop offset="1" stop-color="' + s.color + '" stop-opacity="0"/></linearGradient>'; }).join('') + '</defs>';
      h += '<g class="axis">';
      ticksY(yMax - yMin, 4).forEach(function (t) { var v = yMin + t; h += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + Y(v) + '" y2="' + Y(v) + '" stroke="rgba(243,236,219,.09)"/><text x="' + (m.l - 8) + '" y="' + (Y(v) + 4) + '" text-anchor="end">' + esc((o.yFmt || String)(v)) + '</text>'; });
      var base = o.series[0].pts, tk = pick(base.length, W < 520 ? 4 : 6);
      tk.forEach(function (i, k) { var p = base[i]; h += '<text x="' + X(p[0]) + '" y="' + (H - 8) + '" text-anchor="' + (k === 0 ? 'start' : k === tk.length - 1 ? 'end' : 'middle') + '">' + esc((o.xFmt || String)(p[0])) + '</text>'; });
      h += '</g>';
      if (o.vline) h += '<line x1="' + X(o.vline.x) + '" x2="' + X(o.vline.x) + '" y1="' + m.t + '" y2="' + (H - m.b) + '" stroke="#D6AA4B" stroke-dasharray="4 4" opacity=".7"/><text x="' + (X(o.vline.x) + 6) + '" y="' + (m.t + 10) + '" fill="#EBCB7E" font-size="11">' + esc(o.vline.label) + '</text>';
      o.series.forEach(function (s, i) {
        var d = s.pts.map(function (p, j) { return (j ? 'L' : 'M') + X(p[0]).toFixed(1) + ' ' + Y(p[1]).toFixed(1); }).join('');
        if (s.area) h += '<path d="' + d + 'L' + X(s.pts[s.pts.length - 1][0]) + ' ' + Y(yMin) + 'L' + X(s.pts[0][0]) + ' ' + Y(yMin) + 'Z" fill="url(#' + id + i + ')"/>';
        h += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"' + (s.dash ? ' stroke-dasharray="6 5"' : '') + '/>';
      });
      h += '<g class="hov" style="display:none"><line y1="' + m.t + '" y2="' + (H - m.b) + '" stroke="rgba(243,236,219,.4)"/>' + o.series.map(function (s) { return '<circle r="4.5" fill="' + s.color + '" stroke="#0A101C" stroke-width="2"/>'; }).join('') + '</g>';
      h += '<rect class="ov" x="' + m.l + '" y="' + m.t + '" width="' + (W - m.l - m.r) + '" height="' + (H - m.t - m.b) + '" fill="transparent"/>';
      el.innerHTML = (o.legend === false ? '' : '<div class="legend">' + o.series.map(function (s) { return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>'; }).join('') + '</div>') +
        '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(o.label || 'Chart') + '">' + h + '</svg><div class="tip"></div>';
      var svg = el.querySelector('svg'), hov = svg.querySelector('.hov'), tip = el.querySelector('.tip'), ov = svg.querySelector('.ov');
      function move(ev) {
        var r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * (W / r.width);
        var xv = x0 + (px - m.l) / (W - m.l - m.r) * (x1 - x0), best = 0, bd = 1e18;
        base.forEach(function (p, i) { var dd = Math.abs(p[0] - xv); if (dd < bd) { bd = dd; best = i; } });
        var cx = X(base[best][0]); hov.style.display = ''; hov.querySelector('line').setAttribute('x1', cx); hov.querySelector('line').setAttribute('x2', cx);
        var circles = hov.querySelectorAll('circle'), rows = [];
        o.series.forEach(function (s, i) { var p = s.pts[Math.min(best, s.pts.length - 1)]; if (!p) return; circles[i].setAttribute('cx', X(p[0])); circles[i].setAttribute('cy', Y(p[1])); rows.push(esc(s.name) + ': ' + esc((o.tipFmt || o.yFmt || String)(p[1]))); });
        tip.innerHTML = esc((o.xFmt || String)(base[best][0])) + '<br>' + rows.join('<br>'); tip.style.display = 'block';
        var lx = cx * (r.width / W), ly = (Y(o.series[0].pts[Math.min(best, o.series[0].pts.length - 1)][1])) * (r.height / H) + (svg.getBoundingClientRect().top - el.getBoundingClientRect().top);
        tip.style.left = Math.min(Math.max(lx, 70), r.width - 70) + 'px'; tip.style.top = ly + 'px';
      }
      ov.addEventListener('pointermove', move); ov.addEventListener('pointerdown', move);
      ov.addEventListener('pointerleave', function () { hov.style.display = 'none'; tip.style.display = 'none'; });
    });
  }
  /* columns({cats:[..], stacks:[{name,color,vals:[..]}], yFmt, xFmt}) stacked columns */
  function columns(el, o) {
    mount(el, function (W) {
      var H = W < 520 ? 260 : 320, m = { l: W < 520 ? 52 : 64, r: 10, t: 14, b: 30 };
      var n = o.cats.length, tot = o.cats.map(function (_, i) { return o.stacks.reduce(function (s, st) { return s + (st.vals[i] || 0); }, 0); });
      var yMax = niceMax(Math.max.apply(null, tot)), bw = (W - m.l - m.r) / n, bwi = Math.max(2, bw * 0.68);
      var Y = function (y) { return H - m.b - y / yMax * (H - m.t - m.b); };
      var h = '<g class="axis">';
      ticksY(yMax, 4).forEach(function (v) { h += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + Y(v) + '" y2="' + Y(v) + '" stroke="rgba(243,236,219,.09)"/><text x="' + (m.l - 8) + '" y="' + (Y(v) + 4) + '" text-anchor="end">' + esc((o.yFmt || String)(v)) + '</text>'; });
      pick(n, Math.max(3, Math.min(n, Math.floor((W - m.l - m.r) / 56)))).forEach(function (i) { h += '<text x="' + (m.l + bw * i + bw / 2) + '" y="' + (H - 8) + '" text-anchor="middle">' + esc((o.xFmt || String)(o.cats[i])) + '</text>'; });
      h += '</g>';
      o.cats.forEach(function (c, i) {
        var acc = 0, x = m.l + bw * i + (bw - bwi) / 2;
        o.stacks.forEach(function (st) { var v = st.vals[i] || 0, y1 = Y(acc + v), y0 = Y(acc); h += '<rect x="' + x.toFixed(1) + '" y="' + y1.toFixed(1) + '" width="' + bwi.toFixed(1) + '" height="' + Math.max(0, y0 - y1).toFixed(1) + '" fill="' + st.color + '" rx="1.5"><title>' + esc((o.xFmt || String)(c) + ' — ' + st.name + ': ' + (o.tipFmt || o.yFmt || String)(v)) + '</title></rect>'; acc += v; });
      });
      el.innerHTML = '<div class="legend">' + o.stacks.map(function (s) { return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>'; }).join('') + '</div><svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(o.label || 'Column chart') + '">' + h + '</svg>';
    });
  }
  function spark(vals, color, w, h) {
    w = w || 84; h = h || 28; var mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals), rg = (mx - mn) || 1;
    var d = vals.map(function (v, i) { return (i ? 'L' : 'M') + (i / (vals.length - 1) * w).toFixed(1) + ' ' + (h - 3 - (v - mn) / rg * (h - 6)).toFixed(1); }).join('');
    return '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true"><path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/></svg>';
  }
  return { line: line, columns: columns, spark: spark, esc: esc };
})();
/* Generated abstract thumbnail (no images, no network) */
window.TBChart.thumb = function (seed, label) {
  var s = seed | 0, r = function () { s = (s * 1664525 + 1013904223) | 0; return ((s >>> 8) & 0xffff) / 65535; };
  var bars = '', n = 7, pts = [];
  for (var i = 0; i < n; i++) { var h = 30 + r() * 90, x = 20 + i * 38; bars += '<rect x="' + x + '" y="' + (170 - h) + '" width="22" height="' + h + '" rx="2" fill="' + (i % 3 === 0 ? '#F3ECDB' : '#22345A') + '" opacity="' + (i % 3 === 0 ? .9 : .85) + '"/>'; pts.push((x + 11) + ',' + (170 - h - 10 - r() * 14)); }
  var net = ''; for (var j = 0; j < 9; j++) net += '<circle cx="' + (r() * 320).toFixed(0) + '" cy="' + (r() * 100).toFixed(0) + '" r="2.2" fill="#D6AA4B" opacity=".35"/>';
  return '<svg viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice" role="img" aria-label="' + (label || 'Illustration') + '"><defs><linearGradient id="tg' + seed + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0A101C"/><stop offset="1" stop-color="#182640"/></linearGradient></defs><rect width="320" height="180" fill="url(#tg' + seed + ')"/>' + net + bars + '<polyline points="' + pts.join(' ') + '" fill="none" stroke="#D6AA4B" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/><circle cx="' + pts[n - 1].split(',')[0] + '" cy="' + pts[n - 1].split(',')[1] + '" r="4" fill="#EBCB7E"/></svg>';
};
