/* My Optimized Balance Sheet™ — assets, liabilities, net worth and line-by-line guidance. Figures stay in this browser (localStorage). */
document.addEventListener('tb:ready', function () {
  var KEY = 'tb_bs_v1', SNAP = 'tb_bs_snaps';
  var TYPES = [['cash', 'Cash and savings'], ['invest', 'Investments and retirement'], ['property', 'Property'], ['vehicle', 'Vehicles'], ['personal', 'Personal and other']];
  var EX = { ccy: 'ZAR', spend: null,
    assets: [{ n: 'Bank savings', t: 'cash', v: 25000 }, { n: 'Retirement fund', t: 'invest', v: 180000 }, { n: 'Home (what it would sell for)', t: 'property', v: 950000 }, { n: 'Car', t: 'vehicle', v: 160000 }, { n: 'Furniture and electronics', t: 'personal', v: 40000 }],
    liabs: [{ n: 'Home loan', v: 780000, r: 11.25 }, { n: 'Vehicle finance', v: 120000, r: 13.5 }, { n: 'Credit card', v: 18000, r: 21 }, { n: 'Store account', v: 6000, r: 24 }] };
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { var x = parseFloat(String(v).replace(/[, ]/g, '')); return isFinite(x) ? x : 0; }
  function conv(v, from) { return from && from !== TB.ccy ? TB.nice(TB.convert(v, from, TB.ccy)) : v; }
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
  function snaps() { try { return JSON.parse(localStorage.getItem(SNAP) || '[]'); } catch (e) { return []; } }
  var money = function (v) { return ' data-money data-ready="1" data-ccy="' + TB.ccy + '" value="' + esc(v) + '"'; };

  function assetRow(a) {
    var opts = TYPES.map(function (t) { return '<option value="' + t[0] + '"' + (a.t === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('');
    return '<div class="bs-row" data-k="a"><div><input class="inp" aria-label="Asset name" placeholder="e.g. Savings account" value="' + esc(a.n) + '" data-f="n"><select class="inp bs-sub" aria-label="Asset type" data-f="t">' + opts + '</select></div>' +
      '<div class="inp-group has-pre"><span class="pre" data-sym>' + TB_DATA.ccy[TB.ccy].sym + '</span><input class="inp" type="number" inputmode="decimal" step="any" min="0" aria-label="Value" data-f="v"' + money(a.v) + '></div>' +
      '<button class="bs-x" type="button" aria-label="Remove">✕</button></div>';
  }
  function liabRow(l) {
    return '<div class="bs-row liab" data-k="l"><input class="inp" aria-label="Debt name" placeholder="e.g. Personal loan" value="' + esc(l.n) + '" data-f="n">' +
      '<div class="inp-group has-pre"><span class="pre" data-sym>' + TB_DATA.ccy[TB.ccy].sym + '</span><input class="inp" type="number" inputmode="decimal" step="any" min="0" aria-label="Balance owed" data-f="v"' + money(l.v) + '></div>' +
      '<div class="inp-group has-suf"><input class="inp" type="number" inputmode="decimal" step="0.25" min="0" max="60" aria-label="Interest rate per year" data-f="r" value="' + esc(l.r) + '"><span class="suf">%</span></div>' +
      '<button class="bs-x" type="button" aria-label="Remove">✕</button></div>';
  }
  function fill(d) {
    $('assets').innerHTML = d.assets.map(function (a) { return assetRow({ n: a.n, t: a.t, v: conv(a.v, d.ccy) }); }).join('');
    $('liabs').innerHTML = d.liabs.map(function (l) { return liabRow({ n: l.n, r: l.r, v: conv(l.v, d.ccy) }); }).join('');
    if (d.spend != null) $('spend').value = conv(d.spend, d.ccy);
  }
  function read() {
    var d = { ccy: TB.ccy, assets: [], liabs: [], spend: num($('spend').value) };
    document.querySelectorAll('.bs-row').forEach(function (r) {
      var g = function (f) { var e = r.querySelector('[data-f="' + f + '"]'); return e ? e.value : ''; };
      if (r.dataset.k === 'a') d.assets.push({ n: g('n'), t: g('t'), v: num(g('v')) }); else d.liabs.push({ n: g('n'), v: num(g('v')), r: num(g('r')) });
    });
    return d;
  }
  function tip(level, title, body) { return '<div class="bs-tip"><span class="bs-dot ' + level + '"></span><div><h4>' + title + '</h4><p>' + body + '</p></div></div>'; }
  function pct(x) { return Math.round(x * 100) + '%'; }

  function run() {
    var d = read(), by = {}, A = 0, L = 0, intM = 0;
    TYPES.forEach(function (t) { by[t[0]] = 0; });
    d.assets.forEach(function (a) { A += a.v; by[a.t] = (by[a.t] || 0) + a.v; });
    d.liabs.forEach(function (l) { L += l.v; intM += l.v * l.r / 100 / 12; });
    var N = A - L;
    $('totA').textContent = TB.fmt(A); $('totL').textContent = TB.fmt(L);
    $('net').textContent = TB.fmt(N); $('net').className = 'v ' + (N >= 0 ? '' : 'down');
    $('neteq').textContent = TB.fmt(A) + ' owned − ' + TB.fmt(L) + ' owed';
    var s = snaps(), last = s[s.length - 1];
    if (last) { var prev = TB.convert(last.a - last.l, last.ccy, TB.ccy), ch = N - prev;
      $('since').innerHTML = '<span class="' + (ch >= 0 ? 'up' : 'down') + '">' + (ch >= 0 ? '▲ ' : '▼ ') + TB.fmt(Math.abs(ch)) + '</span> <span class="muted">since your snapshot on ' + esc(last.d) + '</span>';
    } else $('since').innerHTML = '<span class="muted">Save a snapshot to track your progress.</span>';

    var t = '';
    if (A <= 0 && L <= 0) t = tip('', 'Start with what you own', 'Add your bank balances, retirement savings, property and vehicles at what they would fetch today, then add every debt.');
    else {
      if (N < 0) t += tip('act', 'Your debts are bigger than your assets', 'Your net worth is below zero. Paying down debt, especially expensive debt, is usually the quickest way to turn it positive.');
      if (A > 0) { var dr = L / A;
        t += dr < .3 ? tip('good', 'Debt ratio: ' + pct(dr), 'You owe less than a third of what you own, which gives you room to absorb shocks.')
          : dr < .5 ? tip('watch', 'Debt ratio: ' + pct(dr), 'You owe between a third and a half of what you own. Each debt you clear lowers this ratio and raises your net worth.')
          : tip('act', 'Debt ratio: ' + pct(dr), 'You owe more than half of what you own. Avoid new debt where you can and direct extra money to the costliest debt below.'); }
      if (d.spend > 0) { var m = by.cash / d.spend;
        t += m >= 3 ? tip('good', 'Safety buffer: ' + m.toFixed(1) + ' months', 'Your cash and savings could cover about ' + m.toFixed(1) + ' months of living costs. Three to six months is a common target.')
          : m >= 1 ? tip('watch', 'Safety buffer: ' + m.toFixed(1) + ' months', 'Building this toward three months of living costs helps keep surprises from becoming new debt.')
          : tip('act', 'Safety buffer: under a month', 'A small emergency fund, even one month of costs, is a common first step before investing more.'); }
      var debts = d.liabs.filter(function (l) { return l.v > 0; }).sort(function (x, y) { return y.r - x.r; });
      if (debts.length) { var top = debts[0];
        t += tip(top.r >= 15 ? 'act' : 'watch', 'Costliest debt: ' + esc(top.n || 'unnamed') + ' at ' + top.r + '%', 'Your debts cost about ' + TB.fmt(intM) + ' a month in interest. Extra payments on the highest-rate debt save the most, because every amount you repay there avoids ' + top.r + '% a year.' +
          (debts.length > 1 ? ' Order to tackle: ' + debts.map(function (l) { return esc(l.n || 'unnamed') + ' (' + l.r + '%)'; }).join(', ') + '.' : ''));
      } else if (A > 0) t += tip('good', 'No debt listed', 'With no debt, every amount you save adds straight to your net worth.');
      if (A > 0) { var dp = (by.vehicle + by.personal) / A, gr = (by.invest + by.property) / A;
        t += dp > .3 ? tip('watch', 'Assets that lose value: ' + pct(dp), 'Vehicles and personal items usually lose value every year, so their share of your net worth shrinks over time. Think twice before adding more on credit.')
          : tip('good', 'Assets that lose value: ' + pct(dp), 'Most of what you own is not in items that lose value quickly.');
        t += gr < .4 ? tip('watch', 'Assets that can grow: ' + pct(gr), 'Investments, retirement funds and property can grow over time. Raising their share is one way to lift net worth over the long run.')
          : tip('good', 'Assets that can grow: ' + pct(gr), 'A good share of what you own can grow over time. Keep contributing regularly.'); }
    }
    $('tips').innerHTML = t;

    $('hist').innerHTML = s.length ? '<table class="tbl" style="width:100%"><thead><tr><th style="text-align:left">Date</th><th>Net worth</th><th>Change</th></tr></thead><tbody>' +
      s.slice(-12).map(function (x, i, arr) { var n = TB.convert(x.a - x.l, x.ccy, TB.ccy), p = i ? TB.convert(arr[i - 1].a - arr[i - 1].l, arr[i - 1].ccy, TB.ccy) : null;
        return '<tr><td style="text-align:left">' + esc(x.d) + '</td><td>' + TB.fmt(n) + '</td><td>' + (p == null ? '<span class="muted">—</span>' : TB.chg ? '<span class="' + (n - p >= 0 ? 'up' : 'down') + '">' + (n - p >= 0 ? '+' : '−') + TB.fmt(Math.abs(n - p)) + '</span>' : '') + '</td></tr>'; }).reverse().join('') + '</tbody></table>'
      : '<p class="small muted" style="margin:0">No snapshots yet.</p>';
    try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) { }
    return { A: A, L: L };
  }

  var saved = load(); fill(saved && saved.assets ? saved : EX);
  var main = $('main');
  main.addEventListener('input', function (e) { if (e.target.closest('.bs-row') || e.target.id === 'spend') run(); });
  main.addEventListener('change', function (e) { if (e.target.closest('.bs-row')) run(); });
  main.addEventListener('click', function (e) { var x = e.target.closest('.bs-x'); if (x) { x.closest('.bs-row').remove(); run(); } });
  $('addAsset').addEventListener('click', function () { $('assets').insertAdjacentHTML('beforeend', assetRow({ n: '', t: 'cash', v: '' })); $('assets').lastElementChild.querySelector('input').focus(); });
  $('addLiab').addEventListener('click', function () { $('liabs').insertAdjacentHTML('beforeend', liabRow({ n: '', v: '', r: '' })); $('liabs').lastElementChild.querySelector('input').focus(); });
  $('snap').addEventListener('click', function () { var r = run(), s = snaps(), dt = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    if (s.length && s[s.length - 1].d === dt) s.pop(); s.push({ d: dt, a: r.A, l: r.L, ccy: TB.ccy }); try { localStorage.setItem(SNAP, JSON.stringify(s.slice(-60))); } catch (e) { } run(); TB.toast('Snapshot saved on this device only'); });
  $('reset').addEventListener('click', function () { if (!confirm('Clear your figures and snapshots from this device?')) return; try { localStorage.removeItem(KEY); localStorage.removeItem(SNAP); } catch (e) { }
    $('assets').innerHTML = assetRow({ n: '', t: 'cash', v: '' }); $('liabs').innerHTML = liabRow({ n: '', v: '', r: '' }); $('spend').value = ''; run(); });
  document.addEventListener('tb:currency', run);
  run();
});
