document.addEventListener('tb:ready', function () {
  var D = TB_DATA, C = TBChart, c = D.clients[0], ccy = c.ccy;
  var r = TBCalc.retirement(D.scenarios[0].params);
  document.getElementById('cstats').innerHTML = TB.kpi('Total assets', TB.fmt(c.aum, { ccy: ccy })) + TB.kpi('Retirement outlook', r.onTrack ? 'On track' : 'Shortfall of ' + TB.compact(r.shortfallReal, ccy)) + TB.kpi('Next review', '18 Nov 2026');
  var pts = []; var v = 1850000; for (var i = 0; i < 12; i++) { v = v * (1 + 0.012 + Math.sin(i * 1.3) * 0.014); pts.push([i, v]); } var k = c.aum / pts[11][1]; pts = pts.map(function (p) { return [p[0], p[1] * k]; });
  var mon = ['Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
  C.line(document.getElementById('nw'), { series: [{ name: 'Net worth (example)', color: '#D6AA4B', area: true, pts: pts }], yMin: pts[0][1] * 0.8, xFmt: function (x) { return mon[Math.round(x)]; }, yFmt: function (x) { return TB.compact(x, ccy); }, tipFmt: function (x) { return TB.fmt(x, { ccy: ccy }); }, label: 'Net worth trend' });
  var goals = [['Retire at 63', 68], ['Emergency fund (6 months)', 92], ['Child’s university fund', 41], ['Pay off bond early', 27]];
  document.getElementById('goals').innerHTML = goals.map(function (g) { return '<div style="margin:12px 0"><div class="split small"><span>' + g[0] + '</span><b>' + g[1] + '%</b></div><div class="progress" style="margin-top:6px"><i style="width:' + g[1] + '%"></i></div></div>'; }).join('');
  document.getElementById('shared').innerHTML = D.scenarios.filter(function (s) { return s.client === 'c1'; }).map(function (s) { return '<div class="mkt-row" style="grid-template-columns:1fr auto"><div><span class="tag" style="margin-right:8px">Shared with you</span><b>' + C.esc(s.label) + '</b><div class="small muted">' + s.date + ' · retirement scenario</div></div></div>'; }).join('') || '<p class="small muted" style="margin:0">Nothing shared yet.</p>';
  var ask = document.getElementById('ask'); if (ask) ask.addEventListener('click', function () { TB.toast('Demo only — no message was sent'); });
});
