document.addEventListener('tb:ready', function () {
  var mode = 'm';
  function draw() { var c = TB_DATA.ccy[TB.ccy]; document.getElementById('pc').textContent = c.code;
    document.querySelectorAll('[data-price]').forEach(function (e) { var zar = +e.dataset.price * (mode === 'y' ? 0.8 : 1); e.textContent = TB.fmt(Math.round(zar / c.toZAR / 10) * 10); }); }
  draw(); document.addEventListener('tb:currency', draw);
  document.getElementById('bill').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; mode = b.dataset.b; this.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); draw(); });
});
