document.addEventListener('tb:ready', function () {
  var C = TBChart, K = TB.kpi;
  TB.calc({
    type: 'retirement', fields: { age: 'age', retAge: 'retAge', planAge: 'planAge', savings: 'savings', monthly: 'monthly', escal: 'escal', preRet: 'preRet', postRet: 'postRet', infl: 'infl', targetIncome: 'targetIncome', salary: 'salary', twoPot: 'twoPot' },
    label: function (p) { return 'Retire at ' + p.retAge + ', ' + TB.compact(p.targetIncome) + '/month target'; },
    valid: function (p) { if (!(p.retAge > p.age)) return 'Retirement age must be above your current age.'; if (!(p.planAge > p.retAge)) return 'Plan age must be above retirement age.'; return true; },
    run: function (p) {
      var r = TBCalc.retirement(p);
      document.getElementById('kpis').innerHTML =
        K('Projected balance at retirement', TB.fmt(r.nominalAtRet)) + K('…in today’s money', TB.fmt(r.realAtRet)) +
        K('Sustainable income (today’s money / month)', TB.fmt(r.sustainableReal), true) + K('Capital needed for target', TB.fmt(r.requiredReal)) +
        K(r.onTrack ? 'Surplus vs target' : 'Shortfall vs target', TB.fmt(Math.abs(r.realAtRet - r.requiredReal))) +
        K(r.onTrack ? 'Extra needed per month' : 'Extra per month to close gap', TB.fmt(r.extraMonthly));
      document.getElementById('verdict').innerHTML = r.onTrack
        ? '<span class="pill ok">On track</span> <span class="small muted">Your projected capital covers the target income to age ' + p.planAge + ' under these assumptions.' + (p.salary ? ' Income replacement: ' + (r.replacement * 100).toFixed(0) + '% of current salary.' : '') + '</span>'
        : '<span class="pill warn">Shortfall</span> <span class="small muted">Saving ' + TB.fmt(r.extraMonthly) + ' more each month (stepping up with your escalation) would close the gap.' + (p.salary ? ' Sustainable income is ' + (r.replacement * 100).toFixed(0) + '% of current salary.' : '') + '</span>';
      var pts = r.years.map(function (y) { return [y.age, y.real]; }).concat(r.draw.slice(1).map(function (d) { return [d.age, d.real]; }));
      var nom = r.years.map(function (y) { return [y.age, y.nominal]; });
      C.line(document.getElementById('chart'), { series: [{ name: 'Today’s money (accumulation then drawdown)', color: '#D6AA4B', pts: pts, area: true }, { name: 'Nominal balance', color: '#7FA0D6', pts: nom, dash: true }],
        xFmt: function (x) { return 'Age ' + Math.round(x); }, yFmt: function (v) { return TB.compact(v); }, tipFmt: function (v) { return TB.fmt(v); }, vline: { x: p.retAge, label: 'Retire' }, label: 'Retirement projection' });
      var pc = document.getElementById('potsCard');
      if (r.pots) { pc.style.display = ''; var tot = r.nominalAtRet; document.getElementById('pots').innerHTML = [['Vested pot', r.pots.vested, '#7FA0D6'], ['Savings pot', r.pots.savings, '#EBCB7E'], ['Retirement pot', r.pots.retirement, '#D6AA4B']].map(function (x) { return '<div style="margin:10px 0"><div class="split small"><span>' + x[0] + '</span><b class="num">' + TB.fmt(x[1]) + ' · ' + (x[1] / tot * 100).toFixed(0) + '%</b></div><div class="progress"><i style="width:' + (x[1] / tot * 100) + '%;background:' + x[2] + '"></i></div></div>'; }).join(''); } else pc.style.display = 'none';
    }
  });
});
