/* Shared calculator wiring: prefill from ?p=, live recompute, save scenario, report link. */
TB.calc = function (cfg) {
  var q = new URLSearchParams(location.search), ids = cfg.fields;
  function el(k) { return document.getElementById(ids[k]); }
  function read() { var p = {}; Object.keys(ids).forEach(function (k) { var e = el(k); if (!e) return; p[k] = e.type === 'checkbox' ? e.checked : (e.tagName === 'SELECT' || e.type === 'text' ? e.value : parseFloat(e.value)); }); return p; }
  if (q.get('p')) { try { var p = JSON.parse(q.get('p')); Object.keys(p).forEach(function (k) { var e = el(k); if (!e) return; if (e.type === 'checkbox') e.checked = !!p[k]; else e.value = p[k]; }); } catch (e) { } }
  function run() {
    var p = read(), ok = cfg.valid ? cfg.valid(p) : true;
    var v = document.getElementById('verdict');
    if (ok !== true) { v.innerHTML = '<div class="warn-box">' + ok + '</div>'; document.getElementById('kpis').style.opacity = .35; return; }
    document.getElementById('kpis').style.opacity = 1; v.innerHTML = '';
    cfg.run(p);
    var rep = document.getElementById('rep'); if (rep) rep.href = 'report.html?type=' + cfg.type + '&ccy=' + TB.ccy + '&p=' + encodeURIComponent(JSON.stringify(p));
  }
  document.querySelector('form.inputs').addEventListener('input', run);
  document.querySelector('form.inputs').addEventListener('change', run);
  document.addEventListener('tb:currency', run);
  var sv = document.getElementById('save'); if (sv) sv.addEventListener('click', function () { TB.saveScenario(cfg.type, cfg.label(read()), TB.ccy, read()); });
  run(); return { run: run, read: read };
};
TB.kpi = function (label, value, hl) { return '<div class="kpi' + (hl ? ' hl' : '') + '"><div class="l">' + label + '</div><div class="v">' + value + '</div></div>'; };
